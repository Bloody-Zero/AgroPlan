from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
import models
import schemas
from passlib.context import CryptContext
from datetime import datetime, timedelta
from typing import List, Optional

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# User CRUD
def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()

def create_user(db: Session, user: schemas.UserCreate):
    hashed_password = pwd_context.hash(user.password)
    db_user = models.User(
        email=user.email,
        password_hash=hashed_password,
        full_name=user.full_name,
        farm_name=user.farm_name,
        region=user.region,
        phone=user.phone
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

# Crop CRUD
def get_crops(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Crop).offset(skip).limit(limit).all()

def get_crop_by_code(db: Session, crop_code: str):
    return db.query(models.Crop).filter(models.Crop.crop_code == crop_code).first()

def get_crop_by_id(db: Session, crop_id: int):
    return db.query(models.Crop).filter(models.Crop.id == crop_id).first()

# Field CRUD
def get_user_fields(db: Session, user_id: int, skip: int = 0, limit: int = 100):
    return db.query(models.Field).filter(models.Field.user_id == user_id).offset(skip).limit(limit).all()

def get_field_by_id(db: Session, field_id: int):
    return db.query(models.Field).filter(models.Field.id == field_id).first()

def create_field(db: Session, field: schemas.FieldCreate, user_id: int):
    db_field = models.Field(**field.dict(), user_id=user_id)
    db.add(db_field)
    db.commit()
    db.refresh(db_field)
    return db_field

def update_field(db: Session, field_id: int, field_update: schemas.FieldCreate):
    db_field = db.query(models.Field).filter(models.Field.id == field_id).first()
    if db_field:
        for key, value in field_update.dict().items():
            setattr(db_field, key, value)
        db.commit()
        db.refresh(db_field)
    return db_field

def delete_field(db: Session, field_id: int):
    db_field = db.query(models.Field).filter(models.Field.id == field_id).first()
    if db_field:
        db.delete(db_field)
        db.commit()
    return db_field

# Planting History CRUD
def get_field_planting_history(db: Session, field_id: int):
    return db.query(models.PlantingHistory).filter(
        models.PlantingHistory.field_id == field_id
    ).order_by(models.PlantingHistory.planting_date.desc()).all()

def create_planting_record(db: Session, planting: schemas.PlantingHistoryCreate):
    db_planting = models.PlantingHistory(**planting.dict())
    db.add(db_planting)
    db.commit()
    db.refresh(db_planting)
    return db_planting

def get_last_planting_for_field(db: Session, field_id: int):
    return db.query(models.PlantingHistory).filter(
        models.PlantingHistory.field_id == field_id
    ).order_by(models.PlantingHistory.planting_date.desc()).first()