from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List

import crud
import schemas
from database import get_db

router = APIRouter(prefix="/crops", tags=["crops"])

@router.get("/", response_model=List[schemas.CropResponse])
def read_crops(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    crops = crud.get_crops(db, skip=skip, limit=limit)
    return crops

@router.get("/{crop_id}", response_model=schemas.CropResponse)
def read_crop(crop_id: int, db: Session = Depends(get_db)):
    crop = crud.get_crop_by_id(db, crop_id)
    if crop is None:
        raise HTTPException(status_code=404, detail="Crop not found")
    return crop