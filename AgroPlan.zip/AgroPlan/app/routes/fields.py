from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

import crud
import schemas
from database import get_db

router = APIRouter(prefix="/fields", tags=["fields"])

# Заглушка для аутентификации
def get_current_user():
    return {"id": 1}  # В реальном приложении получать из токена

@router.get("/", response_model=List[schemas.FieldResponse])
def read_fields(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    fields = crud.get_user_fields(db, user_id=current_user["id"], skip=skip, limit=limit)
    return fields

@router.post("/", response_model=schemas.FieldResponse)
def create_field(
    field: schemas.FieldCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    return crud.create_field(db=db, field=field, user_id=current_user["id"])

@router.get("/{field_id}", response_model=schemas.FieldResponse)
def read_field(field_id: int, db: Session = Depends(get_db)):
    db_field = crud.get_field_by_id(db, field_id=field_id)
    if db_field is None:
        raise HTTPException(status_code=404, detail="Field not found")
    return db_field

@router.put("/{field_id}", response_model=schemas.FieldResponse)
def update_field(
    field_id: int,
    field: schemas.FieldCreate,
    db: Session = Depends(get_db)
):
    db_field = crud.update_field(db, field_id=field_id, field_update=field)
    if db_field is None:
        raise HTTPException(status_code=404, detail="Field not found")
    return db_field

@router.delete("/{field_id}")
def delete_field(field_id: int, db: Session = Depends(get_db)):
    db_field = crud.delete_field(db, field_id=field_id)
    if db_field is None:
        raise HTTPException(status_code=404, detail="Field not found")
    return {"message": "Field deleted successfully"}