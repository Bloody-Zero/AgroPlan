from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

import crud
import schemas
from database import get_db

router = APIRouter(prefix="/planting", tags=["planting"])

@router.get("/field/{field_id}", response_model=List[schemas.PlantingHistoryResponse])
def get_field_history(field_id: int, db: Session = Depends(get_db)):
    history = crud.get_field_planting_history(db, field_id)
    return history

@router.post("/", response_model=schemas.PlantingHistoryResponse)
def create_planting_record(
    planting: schemas.PlantingHistoryCreate,
    db: Session = Depends(get_db)
):
    return crud.create_planting_record(db=db, planting=planting)