from pydantic import BaseModel, EmailStr
from typing import Optional, List, Any, Dict
from datetime import datetime, date


class UserBase(BaseModel):
    email: EmailStr
    full_name: str
    farm_name: Optional[str] = None
    region: Optional[str] = None
    phone: Optional[str] = None


class UserCreate(UserBase):
    password: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(UserBase):
    id: int
    role: str
    subscription_type: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class CropBase(BaseModel):
    crop_code: str
    name_ru: str
    type: str
    family: str
    nitrogen_effect: str
    return_interval_years: int
    notes: Optional[str] = None


class CropResponse(CropBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True


class FieldBase(BaseModel):
    name: str
    area_hectares: float
    geometry_json: Dict[str, Any]
    soil_type: Optional[str] = None
    ph_level: Optional[float] = None
    nitrogen_content: Optional[float] = None
    phosphorus_content: Optional[float] = None
    potassium_content: Optional[float] = None
    notes: Optional[str] = None


class FieldCreate(FieldBase):
    pass


class FieldResponse(FieldBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class PlantingHistoryBase(BaseModel):
    field_id: int
    crop_id: int
    planting_date: date
    harvest_date: Optional[date] = None
    season_year: int
    yield_kg: Optional[float] = None
    yield_per_hectare: Optional[float] = None
    notes: Optional[str] = None


class PlantingHistoryCreate(PlantingHistoryBase):
    pass


class PlantingHistoryResponse(PlantingHistoryBase):
    id: int
    created_at: datetime
    crop: CropResponse

    class Config:
        from_attributes = True


class CalculationRequest(BaseModel):
    crop_id: int
    area_hectares: float
    region: Optional[str] = None


class CalculationResponse(BaseModel):
    crop_name: str
    area_hectares: float
    seed_cost: float
    fertilizer_cost: float
    other_costs: float
    total_cost: float
    expected_revenue: float
    expected_profit: float
    profitability_percent: float


class RecommendationRequest(BaseModel):
    field_id: int
    target_crop_id: int


class RecommendationResponse(BaseModel):
    recommended_crops: List[CropResponse]
    reasoning: str
    confidence_score: float


class Token(BaseModel):
    access_token: str
    token_type: str