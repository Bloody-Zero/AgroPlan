from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app import schemas
from database import engine, get_db
import models
from routes import users, fields, crops, planting
from services.calculator import EconomicCalculator
from services.recommendations import CropRecommender

# Создаем таблицы в БД
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AgroApp API",
    description="API для управления сельскохозяйственными угодьями и планирования севооборота",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Подключаем роутеры
app.include_router(users.router)
app.include_router(fields.router)
app.include_router(crops.router)
app.include_router(planting.router)

# Инициализация сервисов
calculator = EconomicCalculator()
recommender = CropRecommender()

@app.get("/")
def read_root():
    return {"message": "Добро пожаловать в AgroApp API"}

@app.get("/calculate")
def calculate_profitability(
    crop_id: int,
    area_hectares: float,
    region: str = None,
    db: Session = Depends(get_db)
):
    result = calculator.calculate_profitability(db, crop_id, area_hectares, region)
    if not result:
        raise HTTPException(status_code=404, detail="Crop not found")
    return result

@app.post("/recommend")
def get_recommendations(
    request: schemas.RecommendationRequest,
    db: Session = Depends(get_db)
):
    result = recommender.get_recommendations(
        db,
        request.field_id,
        request.target_crop_id
    )
    if not result:
        raise HTTPException(status_code=404, detail="Field or crop not found")
    return result

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)