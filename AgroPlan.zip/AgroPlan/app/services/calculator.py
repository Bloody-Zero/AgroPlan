from sqlalchemy.orm import Session
import crud
from typing import Dict


class EconomicCalculator:
    def __init__(self):
        # Базовые цены (в реальном приложении брать из БД)
        self.base_prices = {
            "wheat": {"seed_cost": 15000, "selling_price": 12000},
            "barley": {"seed_cost": 12000, "selling_price": 10000},
            "corn": {"seed_cost": 25000, "selling_price": 15000},
            "sunflower": {"seed_cost": 18000, "selling_price": 30000},
            "peas": {"seed_cost": 20000, "selling_price": 25000},
            "potato": {"seed_cost": 40000, "selling_price": 15000},
            "soybean": {"seed_cost": 35000, "selling_price": 40000}
        }

        self.yield_per_hectare = {
            "wheat": 3.5,  # тонн с гектара
            "barley": 3.0,
            "corn": 6.0,
            "sunflower": 2.5,
            "peas": 2.0,
            "potato": 25.0,
            "soybean": 2.2
        }

    def calculate_profitability(self, db: Session, crop_id: int, area_hectares: float, region: str = None):
        crop = crud.get_crop_by_id(db, crop_id)
        if not crop:
            return None

        crop_data = self.base_prices.get(crop.crop_code, self.base_prices["wheat"])

        # Расчет затрат
        seed_cost = crop_data["seed_cost"] * area_hectares
        fertilizer_cost = 8000 * area_hectares  # Средние затраты на удобрения
        other_costs = 5000 * area_hectares  # Топливо, техника, etc

        total_cost = seed_cost + fertilizer_cost + other_costs

        # Расчет дохода
        expected_yield = self.yield_per_hectare.get(crop.crop_code, 2.0) * area_hectares
        expected_revenue = expected_yield * crop_data["selling_price"]

        # Расчет прибыли
        expected_profit = expected_revenue - total_cost
        profitability_percent = (expected_profit / total_cost) * 100 if total_cost > 0 else 0

        return {
            "crop_name": crop.name_ru,
            "area_hectares": area_hectares,
            "seed_cost": seed_cost,
            "fertilizer_cost": fertilizer_cost,
            "other_costs": other_costs,
            "total_cost": total_cost,
            "expected_revenue": expected_revenue,
            "expected_profit": expected_profit,
            "profitability_percent": profitability_percent
        }