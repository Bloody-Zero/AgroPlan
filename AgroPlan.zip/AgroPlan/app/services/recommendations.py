from sqlalchemy.orm import Session
import crud
from typing import List, Dict


class CropRecommender:
    def __init__(self):
        self.crop_rules = {
            "wheat": {
                "good_predecessors": ["peas", "bean", "rape"],
                "bad_predecessors": ["wheat", "barley", "oat"]
            },
            "barley": {
                "good_predecessors": ["peas", "bean", "rape"],
                "bad_predecessors": ["wheat", "barley", "oat"]
            },
            "corn": {
                "good_predecessors": ["peas", "bean", "wheat"],
                "bad_predecessors": ["corn", "sunflower"]
            },
            "sunflower": {
                "good_predecessors": ["peas", "bean", "wheat"],
                "bad_predecessors": ["sunflower", "corn"]
            },
            "peas": {
                "good_predecessors": ["wheat", "barley", "oat"],
                "bad_predecessors": ["peas", "bean"]
            },
            "potato": {
                "good_predecessors": ["peas", "bean"],
                "bad_predecessors": ["potato", "tomato"]
            }
        }

    def get_recommendations(self, db: Session, field_id: int, target_crop_id: int):
        field = crud.get_field_by_id(db, field_id)
        target_crop = crud.get_crop_by_id(db, target_crop_id)

        if not field or not target_crop:
            return None

        # Получаем историю посадок для поля
        planting_history = crud.get_field_planting_history(db, field_id)

        if not planting_history:
            return self._get_initial_recommendations(db, target_crop)

        # Анализируем последние посадки
        last_crop = planting_history[0].crop
        recommendations = self._analyze_crop_sequence(last_crop, target_crop)

        return recommendations

    def _get_initial_recommendations(self, db: Session, target_crop: any):
        # Для новых полей рекомендуем культуры-сидераты или бобовые для подготовки почвы
        all_crops = crud.get_crops(db)
        good_preparatory_crops = [
            crop for crop in all_crops
            if crop.nitrogen_effect == "enrich" or crop.crop_code == "siderate_mix"
        ]

        return {
            "recommended_crops": good_preparatory_crops[:3],
            "reasoning": "Поле новое. Рекомендуем начать с культур, обогащающих почву азотом.",
            "confidence_score": 0.8
        }

    def _analyze_crop_sequence(self, last_crop: any, target_crop: any):
        target_rules = self.crop_rules.get(target_crop.crop_code, {})

        good_predecessors = target_rules.get("good_predecessors", [])
        bad_predecessors = target_rules.get("bad_predecessors", [])

        reasoning = ""
        confidence = 0.7

        if last_crop.crop_code in good_predecessors:
            reasoning = f"Отличный выбор! {last_crop.name_ru} является хорошим предшественником для {target_crop.name_ru}."
            confidence = 0.9
        elif last_crop.crop_code in bad_predecessors:
            reasoning = f"Внимание! {last_crop.name_ru} не рекомендуется как предшественник для {target_crop.name_ru}. Рассмотрите другие культуры."
            confidence = 0.3
        else:
            reasoning = f"Нейтральный предшественник. {last_crop.name_ru} можно использовать перед {target_crop.name_ru}, но есть лучшие варианты."
            confidence = 0.6

        return {
            "reasoning": reasoning,
            "confidence_score": confidence
        }