from sqlalchemy import Column, Integer, String, Float, Text, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(200), nullable=False)
    farm_name = Column(String(200))
    region = Column(String(100))
    phone = Column(String(20))
    role = Column(String(20), default="farmer")
    subscription_type = Column(String(20), default="free")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    last_login = Column(DateTime(timezone=True))
    is_active = Column(Boolean, default=True)

    fields = relationship("Field", back_populates="owner")


class Crop(Base):
    __tablename__ = "crops"

    id = Column(Integer, primary_key=True, index=True)
    crop_code = Column(String(50), unique=True, nullable=False)
    name_ru = Column(String(100), nullable=False)
    type = Column(String(50), nullable=False)
    family = Column(String(100), nullable=False)
    nitrogen_effect = Column(String(20), nullable=False)
    return_interval_years = Column(Integer, nullable=False)
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Field(Base):
    __tablename__ = "fields"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(200), nullable=False)
    area_hectares = Column(Float, nullable=False)
    geometry_json = Column(JSON, nullable=False)  # Временное решение вместо PostGIS
    soil_type = Column(String(50))
    ph_level = Column(Float)
    nitrogen_content = Column(Float)
    phosphorus_content = Column(Float)
    potassium_content = Column(Float)
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    owner = relationship("User", back_populates="fields")
    planting_history = relationship("PlantingHistory", back_populates="field")


class PlantingHistory(Base):
    __tablename__ = "planting_history"

    id = Column(Integer, primary_key=True, index=True)
    field_id = Column(Integer, ForeignKey("fields.id", ondelete="CASCADE"), nullable=False)
    crop_id = Column(Integer, ForeignKey("crops.id"), nullable=False)
    planting_date = Column(DateTime, nullable=False)
    harvest_date = Column(DateTime)
    season_year = Column(Integer, nullable=False)
    yield_kg = Column(Float)
    yield_per_hectare = Column(Float)
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    field = relationship("Field", back_populates="planting_history")
    crop = relationship("Crop")


class MarketPrice(Base):
    __tablename__ = "market_prices"

    id = Column(Integer, primary_key=True, index=True)
    crop_id = Column(Integer, ForeignKey("crops.id"), nullable=False)
    price_per_kg = Column(Float, nullable=False)
    price_type = Column(String(20), default="selling")
    region = Column(String(100))
    source = Column(String(100), nullable=False)
    valid_from = Column(DateTime, nullable=False)
    valid_to = Column(DateTime)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    crop = relationship("Crop")