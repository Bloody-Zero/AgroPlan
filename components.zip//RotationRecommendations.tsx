import { useState, useEffect } from 'react';
import { Lightbulb, AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import type { Field } from './MapFieldManager';
import type { CropRecord } from './CropHistoryJournal';

interface CropData {
  name: string;
  category: 'grain' | 'legume' | 'oilseed' | 'root' | 'forage';
  nitrogenBalance: number; // положительный = обогащает, отрицательный = истощает
  goodPredecessors: string[];
  badPredecessors: string[];
  recommendation: string;
}

const CROPS_DATA: Record<string, CropData> = {
  'Пшеница озимая': {
    name: 'Пшеница озимая',
    category: 'grain',
    nitrogenBalance: -80,
    goodPredecessors: ['Горох', 'Соя', 'Многолетние травы', 'Однолетние травы', 'Рапс'],
    badPredecessors: ['Пшеница озимая', 'Пшеница яровая', 'Ячмень', 'Овес'],
    recommendation: 'Требует хорошего предшественника. Лучше всего после бобовых или трав.',
  },
  'Пшеница яровая': {
    name: 'Пшеница яровая',
    category: 'grain',
    nitrogenBalance: -70,
    goodPredecessors: ['Картофель', 'Сахарная свекла', 'Горох', 'Соя', 'Кукуруза'],
    badPredecessors: ['Пшеница озимая', 'Пшеница яровая', 'Овес'],
    recommendation: 'Хорошо растет после пропашных культур и бобовых.',
  },
  'Ячмень': {
    name: 'Ячмень',
    category: 'grain',
    nitrogenBalance: -60,
    goodPredecessors: ['Картофель', 'Сахарная свекла', 'Кукуруза', 'Горох'],
    badPredecessors: ['Пшеница озимая', 'Овес'],
    recommendation: 'Менее требователен к предшественникам, чем пшеница.',
  },
  'Овес': {
    name: 'Овес',
    category: 'grain',
    nitrogenBalance: -50,
    goodPredecessors: ['Картофель', 'Лен', 'Многолетние травы'],
    badPredecessors: ['Овес'],
    recommendation: 'Один из лучших санитарных предшественников.',
  },
  'Рожь': {
    name: 'Рожь',
    category: 'grain',
    nitrogenBalance: -50,
    goodPredecessors: ['Картофель', 'Многолетние травы', 'Горох'],
    badPredecessors: ['Рожь', 'Пшеница озимая'],
    recommendation: 'Неприхотлива, может расти на бедных почвах.',
  },
  'Кукуруза': {
    name: 'Кукуруза',
    category: 'grain',
    nitrogenBalance: -90,
    goodPredecessors: ['Горох', 'Соя', 'Пшеница озимая', 'Многолетние травы'],
    badPredecessors: ['Подсолнечник'],
    recommendation: 'Требовательна к плодородию почвы.',
  },
  'Горох': {
    name: 'Горох',
    category: 'legume',
    nitrogenBalance: 40,
    goodPredecessors: ['Пшеница озимая', 'Ячмень', 'Кукуруза', 'Картофель'],
    badPredecessors: ['Горох', 'Соя', 'Подсолнечник'],
    recommendation: 'Отличный азотфиксатор. Улучшает структуру почвы.',
  },
  'Соя': {
    name: 'Соя',
    category: 'legume',
    nitrogenBalance: 50,
    goodPredecessors: ['Пшеница озимая', 'Кукуруза', 'Ячмень'],
    badPredecessors: ['Горох', 'Соя', 'Подсолнечник'],
    recommendation: 'Обогащает почву азотом. Хороший предшественник для зерновых.',
  },
  'Подсолнечник': {
    name: 'Подсолнечник',
    category: 'oilseed',
    nitrogenBalance: -100,
    goodPredecessors: ['Пшеница озимая', 'Ячмень', 'Кукуруза'],
    badPredecessors: ['Подсолнечник', 'Сахарная свекла', 'Рапс', 'Горох', 'Соя'],
    recommendation: 'Сильно истощает почву. Возврат на поле не раньше 7-8 лет.',
  },
  'Рапс': {
    name: 'Рапс',
    category: 'oilseed',
    nitrogenBalance: -70,
    goodPredecessors: ['Пшеница озимая', 'Ячмень', 'Горох'],
    badPredecessors: ['Рапс', 'Подсолнечник'],
    recommendation: 'Хороший предшественник для зерновых.',
  },
  'Сахарная свекла': {
    name: 'Сахарная свекла',
    category: 'root',
    nitrogenBalance: -80,
    goodPredecessors: ['Пшеница озимая', 'Ячмень', 'Горох'],
    badPredecessors: ['Сахарная свекла', 'Подсолнечник'],
    recommendation: 'Требовательна к плодородию. Возврат не раньше 3-4 лет.',
  },
  'Картофель': {
    name: 'Картофель',
    category: 'root',
    nitrogenBalance: -60,
    goodPredecessors: ['Пшеница озимая', 'Ячмень', 'Горох', 'Многолетние травы'],
    badPredecessors: ['Картофель', 'Подсолнечник'],
    recommendation: 'Хороший предшественник для зерновых.',
  },
  'Лен': {
    name: 'Лен',
    category: 'grain',
    nitrogenBalance: -50,
    goodPredecessors: ['Многолетние травы', 'Картофель', 'Пшеница озимая'],
    badPredecessors: ['Лен', 'Подсолнечник'],
    recommendation: 'Требует хорошего предшественника. Возврат через 6-7 лет.',
  },
  'Гречиха': {
    name: 'Гречиха',
    category: 'grain',
    nitrogenBalance: -30,
    goodPredecessors: ['Многолетние травы', 'Горох', 'Картофель'],
    badPredecessors: ['Гречиха', 'Овес'],
    recommendation: 'Неприхотлива к предшественникам.',
  },
  'Многолетние травы': {
    name: 'Многолетние травы',
    category: 'forage',
    nitrogenBalance: 60,
    goodPredecessors: ['Пшеница озимая', 'Ячмень', 'Овес'],
    badPredecessors: [],
    recommendation: 'Отличный почвоулучшитель. Обогащает почву азотом и органикой.',
  },
  'Однолетние травы': {
    name: 'Однолетние травы',
    category: 'forage',
    nitrogenBalance: 30,
    goodPredecessors: ['Пшеница озимая', 'Ячмень', 'Кукуруза'],
    badPredecessors: [],
    recommendation: 'Хороший санитарный предшественник.',
  },
};

export function RotationRecommendations() {
  const [fields, setFields] = useState<Field[]>([]);
  const [records, setRecords] = useState<CropRecord[]>([]);
  const [selectedField, setSelectedField] = useState('');
  const [selectedNextCrop, setSelectedNextCrop] = useState('');
  const [recommendation, setRecommendation] = useState<{
    score: number;
    status: 'good' | 'acceptable' | 'bad';
    reasons: string[];
    suggestions: string[];
  } | null>(null);

  useEffect(() => {
    const savedFields = localStorage.getItem('fields');
    if (savedFields) {
      setFields(JSON.parse(savedFields));
    }

    const savedRecords = localStorage.getItem('cropRecords');
    if (savedRecords) {
      setRecords(JSON.parse(savedRecords));
    }
  }, []);

  const analyzeRotation = () => {
    if (!selectedField || !selectedNextCrop) return;

    const fieldRecords = records
      .filter((r) => r.fieldId === selectedField)
      .sort((a, b) => b.year - a.year);

    if (fieldRecords.length === 0) {
      setRecommendation({
        score: 80,
        status: 'good',
        reasons: ['История поля отсутствует - можно начать с любой культуры'],
        suggestions: [
          'Рекомендуется начать с бобовых культур или многолетних трав для обогащения почвы',
          'Избегайте подсолнечника и сахарной свеклы в начале севооборота',
        ],
      });
      return;
    }

    const lastCrop = fieldRecords[0].cropType;
    const nextCropData = CROPS_DATA[selectedNextCrop];
    
    let score = 50;
    const reasons: string[] = [];
    const suggestions: string[] = [];

    // Проверка на хорошего предшественника
    if (nextCropData.goodPredecessors.includes(lastCrop)) {
      score += 30;
      reasons.push(`✓ ${lastCrop} - хороший предшественник для ${selectedNextCrop}`);
    } else if (nextCropData.badPredecessors.includes(lastCrop)) {
      score -= 40;
      reasons.push(`✗ ${lastCrop} - плохой предшественник для ${selectedNextCrop}`);
      suggestions.push(`После ${lastCrop} лучше посадить: ${nextCropData.goodPredecessors.slice(0, 3).join(', ')}`);
    } else {
      reasons.push(`○ ${lastCrop} - приемлемый предшественник для ${selectedNextCrop}`);
    }

    // Проверка на монокультуру
    if (lastCrop === selectedNextCrop) {
      score -= 30;
      reasons.push('✗ Монокультура! Посадка одной и той же культуры подряд сильно истощает почву');
      suggestions.push('Рекомендуется чередование культур для поддержания плодородия');
    }

    // Проверка истории за последние 3 года
    const recentCrops = fieldRecords.slice(0, 3).map(r => r.cropType);
    if (recentCrops.filter(c => c === selectedNextCrop).length > 0) {
      score -= 10;
      reasons.push(`⚠ ${selectedNextCrop} уже выращивался на этом поле в последние 3 года`);
    }

    // Анализ баланса азота
    const lastCropData = CROPS_DATA[lastCrop];
    if (lastCropData) {
      if (lastCropData.nitrogenBalance < 0 && nextCropData.nitrogenBalance > 0) {
        score += 20;
        reasons.push(`✓ Чередование истощающей и обогащающей культуры - правильный севооборот`);
      } else if (lastCropData.nitrogenBalance < -80 && nextCropData.nitrogenBalance < -80) {
        score -= 20;
        reasons.push(`⚠ Две истощающие культуры подряд - почва сильно потеряет в плодородии`);
        suggestions.push('Рекомендуется включить в севооборот бобовые или многолетние травы');
      }
    }

    // Специальные рекомендации
    suggestions.push(nextCropData.recommendation);

    // Определение статуса
    let status: 'good' | 'acceptable' | 'bad';
    if (score >= 70) status = 'good';
    else if (score >= 40) status = 'acceptable';
    else status = 'bad';

    setRecommendation({ score, status, reasons, suggestions });
  };

  useEffect(() => {
    if (selectedField && selectedNextCrop) {
      analyzeRotation();
    } else {
      setRecommendation(null);
    }
  }, [selectedField, selectedNextCrop]);

  const getFieldHistory = (fieldId: string) => {
    return records
      .filter((r) => r.fieldId === fieldId)
      .sort((a, b) => b.year - a.year)
      .slice(0, 5);
  };

  return (
    <div className="space-y-6">
      {fields.length === 0 ? (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
          <div>
            <h3 className="text-yellow-900 mb-1">Нет добавленных полей</h3>
            <p className="text-yellow-700">
              Добавьте поля и заполните историю культур для получения рекомендаций по севообороту.
            </p>
          </div>
        </div>
      ) : (
        <>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <div className="flex items-start gap-3 mb-4">
              <Lightbulb className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="text-blue-900 mb-1">Интеллектуальные рекомендации</h3>
                <p className="text-blue-700">
                  Выберите поле и планируемую культуру для получения агрономической оценки севооборота.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-700 mb-2">Выберите поле</label>
                <select
                  value={selectedField}
                  onChange={(e) => setSelectedField(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                >
                  <option value="">-- Выберите поле --</option>
                  {fields.map((field) => (
                    <option key={field.id} value={field.id}>
                      {field.name} ({field.area} га)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Планируемая культура</label>
                <select
                  value={selectedNextCrop}
                  onChange={(e) => setSelectedNextCrop(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                >
                  <option value="">-- Выберите культуру --</option>
                  {Object.keys(CROPS_DATA).map((crop) => (
                    <option key={crop} value={crop}>
                      {crop}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {selectedField && (
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
              <h3 className="text-gray-900 mb-3">История поля: {fields.find(f => f.id === selectedField)?.name}</h3>
              {getFieldHistory(selectedField).length === 0 ? (
                <p className="text-gray-500">История посевов отсутствует</p>
              ) : (
                <div className="space-y-2">
                  {getFieldHistory(selectedField).map((record) => (
                    <div key={record.id} className="flex items-center gap-3 bg-white p-3 rounded-lg">
                      <span className="text-gray-900 min-w-[60px]">{record.year}</span>
                      <span className="text-gray-700">{record.cropType}</span>
                      {CROPS_DATA[record.cropType] && (
                        <span className={`ml-auto px-3 py-1 rounded text-white ${
                          CROPS_DATA[record.cropType].nitrogenBalance > 0
                            ? 'bg-green-600'
                            : CROPS_DATA[record.cropType].nitrogenBalance < -70
                            ? 'bg-red-600'
                            : 'bg-yellow-600'
                        }`}>
                          {CROPS_DATA[record.cropType].nitrogenBalance > 0 ? '+' : ''}
                          {CROPS_DATA[record.cropType].nitrogenBalance} N
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {recommendation && (
            <div className={`border-2 rounded-lg p-6 ${
              recommendation.status === 'good'
                ? 'bg-green-50 border-green-300'
                : recommendation.status === 'acceptable'
                ? 'bg-yellow-50 border-yellow-300'
                : 'bg-red-50 border-red-300'
            }`}>
              <div className="flex items-start gap-3 mb-4">
                {recommendation.status === 'good' && <CheckCircle className="w-6 h-6 text-green-600" />}
                {recommendation.status === 'acceptable' && <AlertCircle className="w-6 h-6 text-yellow-600" />}
                {recommendation.status === 'bad' && <XCircle className="w-6 h-6 text-red-600" />}
                <div>
                  <h3 className={
                    recommendation.status === 'good'
                      ? 'text-green-900'
                      : recommendation.status === 'acceptable'
                      ? 'text-yellow-900'
                      : 'text-red-900'
                  }>
                    {recommendation.status === 'good' && 'Рекомендуется'}
                    {recommendation.status === 'acceptable' && 'Приемлемо'}
                    {recommendation.status === 'bad' && 'Не рекомендуется'}
                  </h3>
                  <p className={
                    recommendation.status === 'good'
                      ? 'text-green-700'
                      : recommendation.status === 'acceptable'
                      ? 'text-yellow-700'
                      : 'text-red-700'
                  }>
                    Оценка севооборота: {recommendation.score}/100
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="text-gray-900 mb-2">Анализ:</h4>
                  <ul className="space-y-1">
                    {recommendation.reasons.map((reason, idx) => (
                      <li key={idx} className="text-gray-700">
                        {reason}
                      </li>
                    ))}
                  </ul>
                </div>

                {recommendation.suggestions.length > 0 && (
                  <div>
                    <h4 className="text-gray-900 mb-2">Рекомендации:</h4>
                    <ul className="space-y-1 list-disc list-inside">
                      {recommendation.suggestions.map((suggestion, idx) => (
                        <li key={idx} className="text-gray-700">
                          {suggestion}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
