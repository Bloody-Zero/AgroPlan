import { useState, useEffect, useRef } from 'react';
import { Plus, Trash2, Edit2, Save, X, ZoomIn, ZoomOut, Move } from 'lucide-react';

export interface Field {
  id: string;
  name: string;
  coordinates: [number, number][];
  area: number;
  center: [number, number];
}

function calculateArea(coordinates: [number, number][]): number {
  if (coordinates.length < 3) return 0;
  
  let area = 0;
  for (let i = 0; i < coordinates.length; i++) {
    const j = (i + 1) % coordinates.length;
    area += coordinates[i][0] * coordinates[j][1];
    area -= coordinates[j][0] * coordinates[i][1];
  }
  area = Math.abs(area) / 2;
  
  // Примерный перевод в гектары (1 пиксель = ~10 метров)
  return Number((area / 10000).toFixed(2));
}

function calculateCenter(coordinates: [number, number][]): [number, number] {
  const x = coordinates.reduce((sum, coord) => sum + coord[0], 0) / coordinates.length;
  const y = coordinates.reduce((sum, coord) => sum + coord[1], 0) / coordinates.length;
  return [x, y];
}

interface CanvasFieldMapProps {
  fields: Field[];
  onFieldComplete: (coords: [number, number][]) => void;
  selectedFieldId?: string;
}

function CanvasFieldMap({ fields, onFieldComplete, selectedFieldId }: CanvasFieldMapProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [points, setPoints] = useState<[number, number][]>([]);
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    drawCanvas();
  }, [fields, points, zoom, offset, selectedFieldId]);

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw grid
    ctx.save();
    ctx.translate(offset.x, offset.y);
    ctx.scale(zoom, zoom);

    drawGrid(ctx, canvas.width / zoom, canvas.height / zoom);

    // Draw saved fields
    fields.forEach((field) => {
      drawField(ctx, field.coordinates, field.id === selectedFieldId ? '#22c55e' : '#10b981', field.name);
    });

    // Draw current drawing
    if (points.length > 0) {
      drawField(ctx, points, '#3b82f6', '', true);
    }

    ctx.restore();
  };

  const drawGrid = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1 / zoom;

    const gridSize = 50;
    const startX = Math.floor(-offset.x / zoom / gridSize) * gridSize;
    const startY = Math.floor(-offset.y / zoom / gridSize) * gridSize;
    const endX = startX + width + gridSize;
    const endY = startY + height + gridSize;

    for (let x = startX; x < endX; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, startY);
      ctx.lineTo(x, endY);
      ctx.stroke();
    }

    for (let y = startY; y < endY; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(startX, y);
      ctx.lineTo(endX, y);
      ctx.stroke();
    }
  };

  const drawField = (
    ctx: CanvasRenderingContext2D,
    coords: [number, number][],
    color: string,
    label: string,
    isPreview = false
  ) => {
    if (coords.length === 0) return;

    // Draw polygon
    ctx.beginPath();
    ctx.moveTo(coords[0][0], coords[0][1]);
    for (let i = 1; i < coords.length; i++) {
      ctx.lineTo(coords[i][0], coords[i][1]);
    }
    ctx.closePath();

    ctx.fillStyle = color + (isPreview ? '40' : '60');
    ctx.fill();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2 / zoom;
    ctx.stroke();

    // Draw points
    coords.forEach((point) => {
      ctx.beginPath();
      ctx.arc(point[0], point[1], 4 / zoom, 0, Math.PI * 2);
      ctx.fillStyle = isPreview ? '#3b82f6' : color;
      ctx.fill();
    });

    // Draw label
    if (label && coords.length > 0) {
      const center = calculateCenter(coords);
      ctx.save();
      ctx.scale(1 / zoom, 1 / zoom);
      ctx.fillStyle = '#1f2937';
      ctx.font = '14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(label, center[0] * zoom, center[1] * zoom);
      ctx.restore();
    }
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || isPanning) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left - offset.x) / zoom;
    const y = (e.clientY - rect.top - offset.y) / zoom;

    setPoints([...points, [x, y]]);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) {
      setIsPanning(true);
      setLastMousePos({ x: e.clientX, y: e.clientY });
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isPanning) {
      const dx = e.clientX - lastMousePos.x;
      const dy = e.clientY - lastMousePos.y;
      setOffset({ x: offset.x + dx, y: offset.y + dy });
      setLastMousePos({ x: e.clientX, y: e.clientY });
    }
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  const startDrawing = () => {
    setIsDrawing(true);
    setPoints([]);
  };

  const finishDrawing = () => {
    if (points.length >= 3) {
      onFieldComplete(points);
      setPoints([]);
    }
    setIsDrawing(false);
  };

  const cancelDrawing = () => {
    setPoints([]);
    setIsDrawing(false);
  };

  const handleZoomIn = () => {
    setZoom(Math.min(zoom * 1.2, 5));
  };

  const handleZoomOut = () => {
    setZoom(Math.max(zoom / 1.2, 0.2));
  };

  const resetView = () => {
    setZoom(1);
    setOffset({ x: 300, y: 300 });
  };

  return (
    <div className="relative">
      <canvas
        ref={canvasRef}
        width={800}
        height={600}
        onClick={handleCanvasClick}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="border border-gray-300 rounded-lg cursor-crosshair bg-white"
        style={{ cursor: isDrawing ? 'crosshair' : isPanning ? 'grabbing' : 'grab' }}
      />

      <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg p-2 space-y-2">
        {!isDrawing ? (
          <>
            <button
              onClick={startDrawing}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 w-full"
            >
              <Plus className="w-4 h-4" />
              Нарисовать поле
            </button>
            <div className="flex gap-2">
              <button
                onClick={handleZoomIn}
                className="p-2 bg-gray-100 hover:bg-gray-200 rounded"
                title="Увеличить"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={handleZoomOut}
                className="p-2 bg-gray-100 hover:bg-gray-200 rounded"
                title="Уменьшить"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                onClick={resetView}
                className="p-2 bg-gray-100 hover:bg-gray-200 rounded"
                title="Сбросить вид"
              >
                <Move className="w-4 h-4" />
              </button>
            </div>
          </>
        ) : (
          <div className="space-y-2">
            <p className="text-green-700 px-2">
              Кликайте для создания границ поля
              <br />
              <span className="text-gray-600">Точек: {points.length}</span>
            </p>
            <button
              onClick={finishDrawing}
              disabled={points.length < 3}
              className="flex items-center gap-1 px-3 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50 w-full"
            >
              <Save className="w-4 h-4" />
              Готово
            </button>
            <button
              onClick={cancelDrawing}
              className="flex items-center gap-1 px-3 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 w-full"
            >
              <X className="w-4 h-4" />
              Отмена
            </button>
          </div>
        )}
      </div>

      <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-3 text-gray-600">
        <p>💡 Перетаскивайте мышью для перемещения</p>
        <p>🔍 Масштаб: {(zoom * 100).toFixed(0)}%</p>
      </div>
    </div>
  );
}

export function MapFieldManager() {
  const [fields, setFields] = useState<Field[]>([]);
  const [editingField, setEditingField] = useState<string | null>(null);
  const [newFieldName, setNewFieldName] = useState('');
  const [showNameDialog, setShowNameDialog] = useState(false);
  const [pendingCoordinates, setPendingCoordinates] = useState<[number, number][] | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('fields');
    if (saved) {
      setFields(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('fields', JSON.stringify(fields));
  }, [fields]);

  const handleFieldComplete = (coordinates: [number, number][]) => {
    setPendingCoordinates(coordinates);
    setShowNameDialog(true);
  };

  const saveNewField = () => {
    if (!pendingCoordinates || !newFieldName.trim()) return;

    const newField: Field = {
      id: Date.now().toString(),
      name: newFieldName,
      coordinates: pendingCoordinates,
      area: calculateArea(pendingCoordinates),
      center: calculateCenter(pendingCoordinates),
    };

    setFields([...fields, newField]);
    setNewFieldName('');
    setShowNameDialog(false);
    setPendingCoordinates(null);
  };

  const deleteField = (id: string) => {
    if (confirm('Вы уверены, что хотите удалить это поле?')) {
      setFields(fields.filter((f) => f.id !== id));
    }
  };

  const updateFieldName = (id: string, name: string) => {
    setFields(fields.map((f) => (f.id === id ? { ...f, name } : f)));
    setEditingField(null);
  };

  return (
    <div className="space-y-4">
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <h3 className="text-green-900 mb-2">Инструкция</h3>
        <p className="text-green-700">
          Нажмите "Нарисовать поле", затем кликайте по холсту для создания границ поля. После завершения введите название поля.
          Используйте мышь для перемещения по карте и кнопки масштабирования.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <CanvasFieldMap 
            fields={fields} 
            onFieldComplete={handleFieldComplete}
            selectedFieldId={editingField || undefined}
          />
        </div>

        <div className="space-y-4">
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-gray-900 mb-3">Мои поля ({fields.length})</h3>
            {fields.length === 0 ? (
              <p className="text-gray-500">Пока нет добавленных полей</p>
            ) : (
              <div className="space-y-2">
                {fields.map((field) => (
                  <div key={field.id} className="bg-white rounded-lg p-3 shadow-sm border border-gray-200">
                    {editingField === field.id ? (
                      <div className="flex gap-2">
                        <input
                          type="text"
                          defaultValue={field.name}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              updateFieldName(field.id, e.currentTarget.value);
                            }
                          }}
                          className="flex-1 px-2 py-1 border border-gray-300 rounded"
                          autoFocus
                        />
                        <button
                          onClick={() => setEditingField(null)}
                          className="p-1 text-gray-500 hover:text-gray-700"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="flex justify-between items-start mb-1">
                          <p className="text-gray-900">{field.name}</p>
                          <div className="flex gap-1">
                            <button
                              onClick={() => setEditingField(field.id)}
                              className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteField(field.id)}
                              className="p-1 text-red-600 hover:bg-red-50 rounded"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                        <p className="text-gray-600">Площадь: {field.area} га</p>
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {showNameDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[10000]">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4 shadow-xl">
            <h3 className="text-gray-900 mb-4">Назовите поле</h3>
            <input
              type="text"
              value={newFieldName}
              onChange={(e) => setNewFieldName(e.target.value)}
              placeholder="Например: Южное поле"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter') saveNewField();
              }}
            />
            <div className="flex gap-3">
              <button
                onClick={saveNewField}
                disabled={!newFieldName.trim()}
                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
              >
                Сохранить
              </button>
              <button
                onClick={() => {
                  setShowNameDialog(false);
                  setNewFieldName('');
                  setPendingCoordinates(null);
                }}
                className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
              >
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
