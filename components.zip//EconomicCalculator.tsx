import { useState, useEffect } from 'react';
import { Calculator, TrendingUp, TrendingDown, Settings } from 'lucide-react';
import type { Field } from './MapFieldManager';
import { PriceManager } from './PriceManager';

interface EconomicData {
  name: string;
  seedCostPerHa: number;
  fertilizerCostPerHa: number;
  pesticidesPerHa: number;
  fuelPerHa: number;
  laborPerHa: number;
  otherCostsPerHa: number;
  yieldPerHa: number; // тонн
  pricePerTon: number; // рублей
}

const ECONOMIC_DATA: Record<string, EconomicData> = {
  'Пшеница озимая': {
    name: 'Пшеница озимая',
    seedCostPerHa: 3500,
    fertilizerCostPerHa: 8000,
    pesticidesPerHa: 4000,
    fuelPerHa: 3000,
    laborPerHa: 5000,
    otherCostsPerHa: 2500,
    yieldPerHa: 4.5,
    pricePerTon: 14000,
  },
  'Пшеница яровая': {
    name: 'Пшеница яровая',
    seedCostPerHa: 4000,
    fertilizerCostPerHa: 7000,
    pesticidesPerHa: 3500,
    fuelPerHa: 2800,
    laborPerHa: 4500,
    otherCostsPerHa: 2000,
    yieldPerHa: 3.5,
    pricePerTon: 13000,
  },
  'Ячмень': {
    name: 'Ячмень',
    seedCostPerHa: 3000,
    fertilizerCostPerHa: 6000,
    pesticidesPerHa: 3000,
    fuelPerHa: 2500,
    laborPerHa: 4000,
    otherCostsPerHa: 1800,
    yieldPerHa: 4.0,
    pricePerTon: 11000,
  },
  'Овес': {
    name: 'Овес',
    seedCostPerHa: 2500,
    fertilizerCostPerHa: 5000,
    pesticidesPerHa: 2000,
    fuelPerHa: 2300,
    laborPerHa: 3500,
    otherCostsPerHa: 1500,
    yieldPerHa: 3.5,
    pricePerTon: 9000,
  },
  'Рожь': {
    name: 'Рожь',
    seedCostPerHa: 2800,
    fertilizerCostPerHa: 5500,
    pesticidesPerHa: 2500,
    fuelPerHa: 2400,
    laborPerHa: 3800,
    otherCostsPerHa: 1600,
    yieldPerHa: 3.8,
    pricePerTon: 10000,
  },
  'Кукуруза': {
    name: 'Кукуруза',
    seedCostPerHa: 8000,
    fertilizerCostPerHa: 12000,
    pesticidesPerHa: 5000,
    fuelPerHa: 4000,
    laborPerHa: 6000,
    otherCostsPerHa: 3000,
    yieldPerHa: 6.5,
    pricePerTon: 12000,
  },
  'Горох': {
    name: 'Горох',
    seedCostPerHa: 6000,
    fertilizerCostPerHa: 4000,
    pesticidesPerHa: 4500,
    fuelPerHa: 2800,
    laborPerHa: 5000,
    otherCostsPerHa: 2200,
    yieldPerHa: 2.5,
    pricePerTon: 18000,
  },
  'Соя': {
    name: 'Соя',
    seedCostPerHa: 7000,
    fertilizerCostPerHa: 3500,
    pesticidesPerHa: 5000,
    fuelPerHa: 3000,
    laborPerHa: 5500,
    otherCostsPerHa: 2500,
    yieldPerHa: 2.0,
    pricePerTon: 25000,
  },
  'Подсолнечник': {
    name: 'Подсолнечник',
    seedCostPerHa: 5000,
    fertilizerCostPerHa: 8000,
    pesticidesPerHa: 6000,
    fuelPerHa: 3500,
    laborPerHa: 6000,
    otherCostsPerHa: 3000,
    yieldPerHa: 2.5,
    pricePerTon: 30000,
  },
  'Рапс': {
    name: 'Рапс',
    seedCostPerHa: 4500,
    fertilizerCostPerHa: 9000,
    pesticidesPerHa: 7000,
    fuelPerHa: 3200,
    laborPerHa: 5500,
    otherCostsPerHa: 2800,
    yieldPerHa: 2.8,
    pricePerTon: 28000,
  },
  'Сахарная свекла': {
    name: 'Сахарная свекла',
    seedCostPerHa: 12000,
    fertilizerCostPerHa: 15000,
    pesticidesPerHa: 8000,
    fuelPerHa: 5000,
    laborPerHa: 12000,
    otherCostsPerHa: 8000,
    yieldPerHa: 45.0,
    pricePerTon: 3500,
  },
  'Картофель': {
    name: 'Картофель',
    seedCostPerHa: 25000,
    fertilizerCostPerHa: 12000,
    pesticidesPerHa: 10000,
    fuelPerHa: 6000,
    laborPerHa: 15000,
    otherCostsPerHa: 10000,
    yieldPerHa: 25.0,
    pricePerTon: 8000,
  },
  'Лен': {
    name: 'Лен',
    seedCostPerHa: 5000,
    fertilizerCostPerHa: 7000,
    pesticidesPerHa: 5500,
    fuelPerHa: 3000,
    laborPerHa: 6000,
    otherCostsPerHa: 3000,
    yieldPerHa: 1.2,
    pricePerTon: 35000,
  },
  'Гречиха': {
    name: 'Гречиха',
    seedCostPerHa: 3500,
    fertilizerCostPerHa: 4000,
    pesticidesPerHa: 2500,
    fuelPerHa: 2500,
    laborPerHa: 4000,
    otherCostsPerHa: 1800,
    yieldPerHa: 1.5,
    pricePerTon: 22000,
  },
  'Многолетние травы': {
    name: 'Многолетние травы',
    seedCostPerHa: 2000,
    fertilizerCostPerHa: 3000,
    pesticidesPerHa: 1000,
    fuelPerHa: 2000,
    laborPerHa: 3000,
    otherCostsPerHa: 1000,
    yieldPerHa: 5.0,
    pricePerTon: 4000,
  },
  'Однолетние травы': {
    name: 'Однолетние травы',
    seedCostPerHa: 2500,
    fertilizerCostPerHa: 3500,
    pesticidesPerHa: 1200,
    fuelPerHa: 2200,
    laborPerHa: 3200,
    otherCostsPerHa: 1200,
    yieldPerHa: 4.0,
    pricePerTon: 3500,
  },
};

export function EconomicCalculator() {
  const [fields, setFields] = useState<Field[]>([]);
  const [selectedCrop, setSelectedCrop] = useState('');
  const [selectedField, setSelectedField] = useState('');
  const [customArea, setCustomArea] = useState('');
  const [showPriceManager, setShowPriceManager] = useState(false);
  const [calculation, setCalculation] = useState<{
    area: number;
    totalCosts: number;
    costsBreakdown: Record<string, number>;
    totalRevenue: number;
    totalYield: number;
    profit: number;
    profitPerHa: number;
    profitMargin: number;
  } | null>(null);

  useEffect(() => {
    const savedFields = localStorage.getItem('fields');
    if (savedFields) {
      setFields(JSON.parse(savedFields));
    }
  }, []);

  // Функция для получения актуальной цены с учётом коэффициентов
  const getAdjustedPrice = (basePrice: number) => {
    const saved = localStorage.getItem('priceCoefficients');
    if (!saved) return basePrice;

    const priceCoefficients = JSON.parse(saved);
    
    // Сезонный коэффициент
    const months = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 
                    'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
    const currentMonth = months[new Date().getMonth()];
    const seasonalCoeff = priceCoefficients.seasonalCoefficients[currentMonth] || 1.0;
    
    // Коэффициент инфляции
    const inflationCoeff = 1 + (priceCoefficients.inflationRate / 100);
    
    // Учитываем время с последнего обновления
    const monthsSinceUpdate = Math.floor(
      (new Date().getTime() - new Date(priceCoefficients.lastUpdated).getTime()) / (1000 * 60 * 60 * 24 * 30)
    );
    const timeCoeff = Math.pow(inflationCoeff, monthsSinceUpdate / 12);
    
    return Math.round(basePrice * seasonalCoeff * timeCoeff);
  };

  // Проверяем, есть ли обновлённая базовая цена
  const getBasePrice = (cropName: string, defaultPrice: number) => {
    const saved = localStorage.getItem('priceCoefficients');
    if (!saved) return defaultPrice;

    const priceCoefficients = JSON.parse(saved);
    return priceCoefficients.basePrices[cropName] || defaultPrice;
  };

  const calculate = () => {
    if (!selectedCrop) return;

    const cropData = ECONOMIC_DATA[selectedCrop];
    let area = 0;

    if (selectedField) {
      const field = fields.find(f => f.id === selectedField);
      area = field?.area || 0;
    } else if (customArea) {
      area = parseFloat(customArea);
    }

    if (area <= 0) return;

    const costsBreakdown = {
      'Семена': cropData.seedCostPerHa * area,
      'Удобрения': cropData.fertilizerCostPerHa * area,
      'Пестициды': cropData.pesticidesPerHa * area,
      'ГСМ': cropData.fuelPerHa * area,
      'Труд': cropData.laborPerHa * area,
      'Прочие расходы': cropData.otherCostsPerHa * area,
    };

    const totalCosts = Object.values(costsBreakdown).reduce((sum, cost) => sum + cost, 0);
    const totalYield = cropData.yieldPerHa * area;
    
    // Используем актуализированную цену
    const basePrice = getBasePrice(selectedCrop, cropData.pricePerTon);
    const adjustedPrice = getAdjustedPrice(basePrice);
    
    const totalRevenue = totalYield * adjustedPrice;
    const profit = totalRevenue - totalCosts;
    const profitPerHa = profit / area;
    const profitMargin = (profit / totalRevenue) * 100;

    setCalculation({
      area,
      totalCosts,
      costsBreakdown,
      totalRevenue,
      totalYield,
      profit,
      profitPerHa,
      profitMargin,
    });
  };

  useEffect(() => {
    if (selectedCrop && (selectedField || customArea)) {
      calculate();
    } else {
      setCalculation(null);
    }
  }, [selectedCrop, selectedField, customArea]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('ru-RU', {
      style: 'currency',
      currency: 'RUB',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="space-y-6">
      {showPriceManager ? (
        <div>
          <button
            onClick={() => setShowPriceManager(false)}
            className="mb-4 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
          >
            ← Вернуться к калькулятору
          </button>
          <PriceManager />
        </div>
      ) : (
        <>
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-start gap-3">
                <Calculator className="w-5 h-5 text-purple-600 mt-0.5" />
                <div>
                  <h3 className="text-purple-900 mb-1">Экономический калькулятор</h3>
                  <p className="text-purple-700">
                    Рассчитайте прогнозируемые затраты и доходы для выбранной культуры с учётом актуальных рыночных цен.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowPriceManager(true)}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 flex items-center gap-2"
              >
                <Settings className="w-4 h-4" />
                Управление ценами
              </button>
            </div>

        <div className="space-y-4">
          <div>
            <label className="block text-gray-700 mb-2">Выберите культуру *</label>
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
            >
              <option value="">-- Выберите культуру --</option>
              {Object.keys(ECONOMIC_DATA).map((crop) => (
                <option key={crop} value={crop}>
                  {crop}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-700 mb-2">Выберите поле (опционально)</label>
              <select
                value={selectedField}
                onChange={(e) => {
                  setSelectedField(e.target.value);
                  setCustomArea('');
                }}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
              >
                <option value="">-- Выберите из списка полей --</option>
                {fields.map((field) => (
                  <option key={field.id} value={field.id}>
                    {field.name} ({field.area} га)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Или введите площадь (га)</label>
              <input
                type="number"
                value={customArea}
                onChange={(e) => {
                  setCustomArea(e.target.value);
                  setSelectedField('');
                }}
                placeholder="Введите площадь"
                min="0"
                step="0.1"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              />
            </div>
          </div>
        </div>
      </div>

      {calculation && (
        <div className="space-y-4">
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h3 className="text-gray-900 mb-4">Результаты расчета</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-blue-50 rounded-lg p-4">
                <p className="text-blue-700 mb-1">Площадь</p>
                <p className="text-blue-900">{calculation.area.toFixed(1)} га</p>
              </div>
              <div className="bg-blue-50 rounded-lg p-4">
                <p className="text-blue-700 mb-1">Урожайность</p>
                <p className="text-blue-900">{ECONOMIC_DATA[selectedCrop].yieldPerHa} т/га</p>
              </div>
              <div className="bg-blue-50 rounded-lg p-4">
                <p className="text-blue-700 mb-1">Общий урожай</p>
                <p className="text-blue-900">{calculation.totalYield.toFixed(1)} т</p>
              </div>
            </div>

            <div className="mb-6">
              <h4 className="text-gray-900 mb-3">Структура затрат</h4>
              <div className="space-y-2">
                {Object.entries(calculation.costsBreakdown).map(([category, cost]) => (
                  <div key={category} className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-gray-700">{category}</span>
                    <span className="text-gray-900">{formatCurrency(cost)}</span>
                  </div>
                ))}
                <div className="flex justify-between items-center py-3 border-t-2 border-gray-300">
                  <span className="text-gray-900">Общие затраты:</span>
                  <span className="text-gray-900">{formatCurrency(calculation.totalCosts)}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-green-700 mb-1">Выручка</p>
                <p className="text-green-900">{formatCurrency(calculation.totalRevenue)}</p>
                <p className="text-green-600 mt-2">
                  Цена: {formatCurrency(getAdjustedPrice(getBasePrice(selectedCrop, ECONOMIC_DATA[selectedCrop].pricePerTon)))}/т
                  {getAdjustedPrice(getBasePrice(selectedCrop, ECONOMIC_DATA[selectedCrop].pricePerTon)) !== ECONOMIC_DATA[selectedCrop].pricePerTon && (
                    <span className="text-orange-600"> (скорректирована)</span>
                  )}
                </p>
              </div>
              <div className={`border-2 rounded-lg p-4 ${
                calculation.profit >= 0
                  ? 'bg-green-50 border-green-300'
                  : 'bg-red-50 border-red-300'
              }`}>
                <div className="flex items-center gap-2 mb-1">
                  {calculation.profit >= 0 ? (
                    <TrendingUp className="w-5 h-5 text-green-600" />
                  ) : (
                    <TrendingDown className="w-5 h-5 text-red-600" />
                  )}
                  <p className={calculation.profit >= 0 ? 'text-green-700' : 'text-red-700'}>
                    Прибыль
                  </p>
                </div>
                <p className={calculation.profit >= 0 ? 'text-green-900' : 'text-red-900'}>
                  {formatCurrency(calculation.profit)}
                </p>
                <p className={calculation.profit >= 0 ? 'text-green-600' : 'text-red-600'} style={{ marginTop: '0.5rem' }}>
                  {formatCurrency(calculation.profitPerHa)}/га • Рентабельность: {calculation.profitMargin.toFixed(1)}%
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
            <p className="text-gray-600">
              <strong>Примечание:</strong> Расчеты основаны на среднерыночных данных и могут отличаться в зависимости от региона, 
              качества почвы, климатических условий и других факторов. Используйте эти данные как ориентировочные для планирования.
              Цены автоматически корректируются с учётом сезонности и инфляции. Для настройки цен используйте кнопку "Управление ценами".
            </p>
          </div>
        </div>
      )}
        </>
      )}
    </div>
  );
}
