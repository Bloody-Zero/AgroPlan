import { useState, useEffect } from 'react';
import { Cloud, Droplets, Wind, Thermometer, Sun, CloudRain, AlertTriangle } from 'lucide-react';

interface WeatherData {
  temperature: number;
  humidity: number;
  precipitation: number;
  windSpeed: number;
  weatherCode: number;
  timestamp: string;
}

interface ForecastData {
  date: string;
  tempMax: number;
  tempMin: number;
  precipitation: number;
  weatherCode: number;
}

export function WeatherData() {
  const [location, setLocation] = useState({ lat: 55.7558, lon: 37.6173 }); // Москва по умолчанию
  const [locationName, setLocationName] = useState('Москва');
  const [currentWeather, setCurrentWeather] = useState<WeatherData | null>(null);
  const [forecast, setForecast] = useState<ForecastData[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [customLat, setCustomLat] = useState('55.7558');
  const [customLon, setCustomLon] = useState('37.6173');

  const REGIONS = [
    { name: 'Москва', lat: 55.7558, lon: 37.6173 },
    { name: 'Краснодар', lat: 45.0355, lon: 38.9753 },
    { name: 'Воронеж', lat: 51.6605, lon: 39.2005 },
    { name: 'Казань', lat: 55.7964, lon: 49.1089 },
    { name: 'Ростов-на-Дону', lat: 47.2357, lon: 39.7015 },
    { name: 'Новосибирск', lat: 55.0084, lon: 82.9357 },
    { name: 'Екатеринбург', lat: 56.8389, lon: 60.6057 },
    { name: 'Пермь', lat: 58.0297, lon: 56.2667 },
  ];

  useEffect(() => {
    fetchWeatherData();
  }, [location]);

  const fetchWeatherData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Используем Open-Meteo API (бесплатный, без ключа)
      const currentUrl = `https://api.open-meteo.com/v1/forecast?latitude=${location.lat}&longitude=${location.lon}&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code&timezone=Europe/Moscow`;
      const forecastUrl = `https://api.open-meteo.com/v1/forecast?latitude=${location.lat}&longitude=${location.lon}&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code&timezone=Europe/Moscow&forecast_days=7`;

      const [currentResponse, forecastResponse] = await Promise.all([
        fetch(currentUrl),
        fetch(forecastUrl)
      ]);

      if (!currentResponse.ok || !forecastResponse.ok) {
        throw new Error('Ошибка при получении данных');
      }

      const currentData = await currentResponse.json();
      const forecastData = await forecastResponse.json();

      setCurrentWeather({
        temperature: currentData.current.temperature_2m,
        humidity: currentData.current.relative_humidity_2m,
        precipitation: currentData.current.precipitation,
        windSpeed: currentData.current.wind_speed_10m,
        weatherCode: currentData.current.weather_code,
        timestamp: currentData.current.time,
      });

      const forecastArray: ForecastData[] = [];
      for (let i = 0; i < 7; i++) {
        forecastArray.push({
          date: forecastData.daily.time[i],
          tempMax: forecastData.daily.temperature_2m_max[i],
          tempMin: forecastData.daily.temperature_2m_min[i],
          precipitation: forecastData.daily.precipitation_sum[i],
          weatherCode: forecastData.daily.weather_code[i],
        });
      }
      setForecast(forecastArray);
    } catch (err) {
      setError('Не удалось загрузить метеоданные. Проверьте интернет-соединение.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getWeatherDescription = (code: number): string => {
    const weatherCodes: Record<number, string> = {
      0: 'Ясно',
      1: 'Преимущественно ясно',
      2: 'Переменная облачность',
      3: 'Пасмурно',
      45: 'Туман',
      48: 'Изморозь',
      51: 'Легкая морось',
      53: 'Морось',
      55: 'Сильная морось',
      61: 'Небольшой дождь',
      63: 'Дождь',
      65: 'Сильный дождь',
      71: 'Небольшой снег',
      73: 'Снег',
      75: 'Сильный снег',
      80: 'Ливень',
      81: 'Сильный ливень',
      95: 'Гроза',
    };
    return weatherCodes[code] || 'Неизвестно';
  };

  const getWeatherIcon = (code: number) => {
    if (code === 0 || code === 1) return <Sun className="w-8 h-8 text-yellow-500" />;
    if (code >= 61 && code <= 65) return <CloudRain className="w-8 h-8 text-blue-500" />;
    if (code >= 71 && code <= 75) return <Cloud className="w-8 h-8 text-gray-400" />;
    if (code >= 80) return <CloudRain className="w-8 h-8 text-blue-600" />;
    return <Cloud className="w-8 h-8 text-gray-500" />;
  };

  const getAgriculturalRecommendations = () => {
    if (!currentWeather) return [];

    const recommendations: { type: 'info' | 'warning' | 'danger'; text: string }[] = [];

    if (currentWeather.temperature < 5) {
      recommendations.push({
        type: 'warning',
        text: 'Низкая температура: заморозки могут повредить молодые всходы. Отложите посев теплолюбивых культур.'
      });
    } else if (currentWeather.temperature > 30) {
      recommendations.push({
        type: 'warning',
        text: 'Высокая температура: усильте полив, растения испытывают тепловой стресс.'
      });
    } else if (currentWeather.temperature >= 15 && currentWeather.temperature <= 25) {
      recommendations.push({
        type: 'info',
        text: 'Оптимальная температура для большинства сельскохозяйственных работ.'
      });
    }

    if (currentWeather.humidity < 30) {
      recommendations.push({
        type: 'warning',
        text: 'Низкая влажность: увеличьте частоту полива, риск пересыхания почвы.'
      });
    } else if (currentWeather.humidity > 80) {
      recommendations.push({
        type: 'warning',
        text: 'Высокая влажность: повышенный риск грибковых заболеваний, усильте профилактику.'
      });
    }

    if (currentWeather.precipitation > 10) {
      recommendations.push({
        type: 'danger',
        text: 'Сильные осадки: отложите полевые работы, риск переувлажнения и эрозии почвы.'
      });
    } else if (currentWeather.precipitation > 0) {
      recommendations.push({
        type: 'info',
        text: 'Осадки: естественное увлажнение почвы, можно снизить интенсивность полива.'
      });
    }

    if (currentWeather.windSpeed > 15) {
      recommendations.push({
        type: 'warning',
        text: 'Сильный ветер: отложите опрыскивание и внесение удобрений, риск сноса препаратов.'
      });
    }

    return recommendations;
  };

  const handleRegionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const region = REGIONS.find(r => r.name === e.target.value);
    if (region) {
      setLocation({ lat: region.lat, lon: region.lon });
      setLocationName(region.name);
      setCustomLat(region.lat.toString());
      setCustomLon(region.lon.toString());
    }
  };

  const handleCustomLocation = () => {
    const lat = parseFloat(customLat);
    const lon = parseFloat(customLon);
    if (!isNaN(lat) && !isNaN(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
      setLocation({ lat, lon });
      setLocationName('Пользовательская точка');
    } else {
      alert('Введите корректные координаты (широта: -90 до 90, долгота: -180 до 180)');
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'short' });
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-blue-900 mb-4">Выбор местоположения</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-700 mb-2">Регион</label>
            <select
              value={locationName}
              onChange={handleRegionChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
            >
              {REGIONS.map((region) => (
                <option key={region.name} value={region.name}>
                  {region.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-gray-700 mb-2">Или введите координаты</label>
            <div className="flex gap-2">
              <input
                type="number"
                value={customLat}
                onChange={(e) => setCustomLat(e.target.value)}
                placeholder="Широта"
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg"
                step="0.0001"
              />
              <input
                type="number"
                value={customLon}
                onChange={(e) => setCustomLon(e.target.value)}
                placeholder="Долгота"
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg"
                step="0.0001"
              />
              <button
                onClick={handleCustomLocation}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Применить
              </button>
            </div>
          </div>
        </div>
      </div>

      {loading && (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
          <p className="mt-4 text-gray-600">Загрузка метеоданных...</p>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {!loading && !error && currentWeather && (
        <>
          <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-lg">
            <h3 className="text-gray-900 mb-4">Текущая погода: {locationName}</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Thermometer className="w-5 h-5 text-orange-600" />
                  <span className="text-gray-700">Температура</span>
                </div>
                <p className="text-orange-900">{currentWeather.temperature.toFixed(1)}°C</p>
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Droplets className="w-5 h-5 text-blue-600" />
                  <span className="text-gray-700">Влажность</span>
                </div>
                <p className="text-blue-900">{currentWeather.humidity}%</p>
              </div>

              <div className="bg-gradient-to-br from-cyan-50 to-cyan-100 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <CloudRain className="w-5 h-5 text-cyan-600" />
                  <span className="text-gray-700">Осадки</span>
                </div>
                <p className="text-cyan-900">{currentWeather.precipitation} мм</p>
              </div>

              <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Wind className="w-5 h-5 text-gray-600" />
                  <span className="text-gray-700">Ветер</span>
                </div>
                <p className="text-gray-900">{currentWeather.windSpeed.toFixed(1)} м/с</p>
              </div>
            </div>

            <div className="mt-6 flex items-center gap-3">
              {getWeatherIcon(currentWeather.weatherCode)}
              <div>
                <p className="text-gray-900">{getWeatherDescription(currentWeather.weatherCode)}</p>
                <p className="text-gray-600">
                  Обновлено: {new Date(currentWeather.timestamp).toLocaleString('ru-RU')}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-6">
            <h3 className="text-green-900 mb-4">Агрономические рекомендации</h3>
            {getAgriculturalRecommendations().length === 0 ? (
              <p className="text-green-700">Погодные условия благоприятны для полевых работ.</p>
            ) : (
              <div className="space-y-3">
                {getAgriculturalRecommendations().map((rec, idx) => (
                  <div
                    key={idx}
                    className={`flex items-start gap-3 p-3 rounded-lg ${
                      rec.type === 'danger'
                        ? 'bg-red-100 border border-red-300'
                        : rec.type === 'warning'
                        ? 'bg-yellow-100 border border-yellow-300'
                        : 'bg-blue-100 border border-blue-300'
                    }`}
                  >
                    <AlertTriangle
                      className={`w-5 h-5 mt-0.5 ${
                        rec.type === 'danger'
                          ? 'text-red-600'
                          : rec.type === 'warning'
                          ? 'text-yellow-600'
                          : 'text-blue-600'
                      }`}
                    />
                    <p
                      className={
                        rec.type === 'danger'
                          ? 'text-red-800'
                          : rec.type === 'warning'
                          ? 'text-yellow-800'
                          : 'text-blue-800'
                      }
                    >
                      {rec.text}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h3 className="text-gray-900 mb-4">Прогноз на 7 дней</h3>
            <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
              {forecast.map((day) => (
                <div key={day.date} className="bg-gray-50 rounded-lg p-3 text-center">
                  <p className="text-gray-600 mb-2">{formatDate(day.date)}</p>
                  <div className="flex justify-center mb-2">
                    {getWeatherIcon(day.weatherCode)}
                  </div>
                  <p className="text-gray-900">
                    {day.tempMax.toFixed(0)}° / {day.tempMin.toFixed(0)}°
                  </p>
                  {day.precipitation > 0 && (
                    <p className="text-blue-600 mt-1">💧 {day.precipitation.toFixed(1)} мм</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
