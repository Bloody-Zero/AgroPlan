import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, AlertCircle, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import type { Field } from './MapFieldManager';

interface SoilData {
  id: string;
  fieldId: string;
  date: string;
  nitrogen: number; // N, мг/кг
  phosphorus: number; // P, мг/кг
  potassium: number; // K, мг/кг
  pH: number;
  organicMatter: number; // %
  notes: string;
}

const NPK_LEVELS = {
  nitrogen: {
    low: 100,
    medium: 150,
    high: 200,
  },
  phosphorus: {
    low: 150,
    medium: 250,
    high: 350,
  },
  potassium: {
    low: 150,
    medium: 250,
    high: 350,
  },
};

const PH_LEVELS = {
  veryAcidic: 5.0,
  acidic: 5.5,
  slightlyAcidic: 6.0,
  neutral: 7.0,
  alkaline: 7.5,
};

export function SoilAnalysis() {
  const [fields, setFields] = useState<Field[]>([]);
  const [soilData, setSoilData] = useState<SoilData[]>([]);
  const [selectedField, setSelectedField] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    nitrogen: '',
    phosphorus: '',
    potassium: '',
    pH: '',
    organicMatter: '',
    notes: '',
  });

  useEffect(() => {
    const savedFields = localStorage.getItem('fields');
    if (savedFields) {
      setFields(JSON.parse(savedFields));
    }

    const savedSoilData = localStorage.getItem('soilData');
    if (savedSoilData) {
      setSoilData(JSON.parse(savedSoilData));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('soilData', JSON.stringify(soilData));
  }, [soilData]);

  const handleSubmit = () => {
    if (!selectedField || !formData.nitrogen || !formData.phosphorus || !formData.potassium || !formData.pH) {
      alert('Заполните все обязательные поля');
      return;
    }

    const newData: SoilData = {
      id: editingId || Date.now().toString(),
      fieldId: selectedField,
      date: new Date().toISOString().split('T')[0],
      nitrogen: parseFloat(formData.nitrogen),
      phosphorus: parseFloat(formData.phosphorus),
      potassium: parseFloat(formData.potassium),
      pH: parseFloat(formData.pH),
      organicMatter: parseFloat(formData.organicMatter) || 0,
      notes: formData.notes,
    };

    if (editingId) {
      setSoilData(soilData.map((d) => (d.id === editingId ? newData : d)));
      setEditingId(null);
    } else {
      setSoilData([...soilData, newData]);
    }

    resetForm();
  };

  const resetForm = () => {
    setFormData({
      nitrogen: '',
      phosphorus: '',
      potassium: '',
      pH: '',
      organicMatter: '',
      notes: '',
    });
    setShowAddForm(false);
    setEditingId(null);
  };

  const handleEdit = (data: SoilData) => {
    setSelectedField(data.fieldId);
    setFormData({
      nitrogen: data.nitrogen.toString(),
      phosphorus: data.phosphorus.toString(),
      potassium: data.potassium.toString(),
      pH: data.pH.toString(),
      organicMatter: data.organicMatter.toString(),
      notes: data.notes,
    });
    setEditingId(data.id);
    setShowAddForm(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Удалить данные анализа почвы?')) {
      setSoilData(soilData.filter((d) => d.id !== id));
    }
  };

  const getNutrientLevel = (value: number, nutrient: 'nitrogen' | 'phosphorus' | 'potassium') => {
    const levels = NPK_LEVELS[nutrient];
    if (value < levels.low) return { level: 'Низкий', color: 'red', icon: <TrendingDown /> };
    if (value < levels.medium) return { level: 'Средний', color: 'yellow', icon: <Minus /> };
    if (value < levels.high) return { level: 'Хороший', color: 'green', icon: <TrendingUp /> };
    return { level: 'Высокий', color: 'blue', icon: <TrendingUp /> };
  };

  const getPhLevel = (pH: number) => {
    if (pH < PH_LEVELS.veryAcidic) return { level: 'Очень кислая', color: 'red' };
    if (pH < PH_LEVELS.acidic) return { level: 'Кислая', color: 'orange' };
    if (pH < PH_LEVELS.slightlyAcidic) return { level: 'Слабокислая', color: 'yellow' };
    if (pH < PH_LEVELS.neutral) return { level: 'Нейтральная', color: 'green' };
    if (pH < PH_LEVELS.alkaline) return { level: 'Слабощелочная', color: 'blue' };
    return { level: 'Щелочная', color: 'purple' };
  };

  const getRecommendations = (data: SoilData) => {
    const recommendations: string[] = [];

    const nLevel = getNutrientLevel(data.nitrogen, 'nitrogen');
    const pLevel = getNutrientLevel(data.phosphorus, 'phosphorus');
    const kLevel = getNutrientLevel(data.potassium, 'potassium');
    const phLevel = getPhLevel(data.pH);

    if (nLevel.level === 'Низкий') {
      recommendations.push('🔴 Необходимо внесение азотных удобрений (мочевина, аммиачная селитра)');
    }
    if (pLevel.level === 'Низкий') {
      recommendations.push('🔴 Необходимо внесение фосфорных удобрений (суперфосфат, аммофос)');
    }
    if (kLevel.level === 'Низкий') {
      recommendations.push('🔴 Необходимо внесение калийных удобрений (хлористый калий, сульфат калия)');
    }

    if (data.pH < 5.5) {
      recommendations.push('🔴 Кислая почва: необходимо известкование (внесение извести, доломитовой муки)');
    } else if (data.pH > 7.5) {
      recommendations.push('⚠️ Щелочная почва: внесите гипс или серу для снижения pH');
    }

    if (data.organicMatter < 2) {
      recommendations.push('⚠️ Низкое содержание органики: внесите навоз, компост или сидераты');
    } else if (data.organicMatter > 4) {
      recommendations.push('✅ Отличное содержание органического вещества');
    }

    if (recommendations.length === 0) {
      recommendations.push('✅ Почва в хорошем состоянии. Поддерживайте текущий уровень плодородия.');
    }

    return recommendations;
  };

  const getFieldData = (fieldId: string) => {
    return soilData
      .filter((d) => d.fieldId === fieldId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const getFieldName = (fieldId: string) => {
    return fields.find((f) => f.id === fieldId)?.name || 'Неизвестное поле';
  };

  return (
    <div className="space-y-6">
      {fields.length === 0 ? (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
          <div>
            <h3 className="text-yellow-900 mb-1">Нет добавленных полей</h3>
            <p className="text-yellow-700">
              Перейдите на вкладку "Учет полей" и добавьте поля, прежде чем проводить анализ почвы.
            </p>
          </div>
        </div>
      ) : (
        <>
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-purple-900 mb-1">Анализ плодородия почв (NPK)</h3>
                <p className="text-purple-700">
                  Ведите учет анализов почвы для мониторинга плодородия и получения рекомендаций по удобрениям.
                </p>
              </div>
              <button
                onClick={() => setShowAddForm(!showAddForm)}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Добавить анализ
              </button>
            </div>

            {showAddForm && (
              <div className="bg-white rounded-lg p-6 border border-purple-200 mt-4">
                <h4 className="text-gray-900 mb-4">
                  {editingId ? 'Редактировать анализ' : 'Новый анализ почвы'}
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-gray-700 mb-2">Поле *</label>
                    <select
                      value={selectedField}
                      onChange={(e) => setSelectedField(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                      disabled={!!editingId}
                    >
                      <option value="">Выберите поле</option>
                      {fields.map((field) => (
                        <option key={field.id} value={field.id}>
                          {field.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-gray-700 mb-2">pH почвы *</label>
                    <input
                      type="number"
                      value={formData.pH}
                      onChange={(e) => setFormData({ ...formData, pH: e.target.value })}
                      placeholder="Например: 6.5"
                      min="3"
                      max="10"
                      step="0.1"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <label className="block text-gray-700 mb-2">Азот (N), мг/кг *</label>
                    <input
                      type="number"
                      value={formData.nitrogen}
                      onChange={(e) => setFormData({ ...formData, nitrogen: e.target.value })}
                      placeholder="Например: 150"
                      min="0"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 mb-2">Фосфор (P), мг/кг *</label>
                    <input
                      type="number"
                      value={formData.phosphorus}
                      onChange={(e) => setFormData({ ...formData, phosphorus: e.target.value })}
                      placeholder="Например: 200"
                      min="0"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 mb-2">Калий (K), мг/кг *</label>
                    <input
                      type="number"
                      value={formData.potassium}
                      onChange={(e) => setFormData({ ...formData, potassium: e.target.value })}
                      placeholder="Например: 180"
                      min="0"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 mb-2">Органическое вещество, %</label>
                  <input
                    type="number"
                    value={formData.organicMatter}
                    onChange={(e) => setFormData({ ...formData, organicMatter: e.target.value })}
                    placeholder="Например: 3.5"
                    min="0"
                    max="15"
                    step="0.1"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 mb-2">Примечания</label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Дополнительные наблюдения..."
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={handleSubmit}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
                  >
                    {editingId ? 'Сохранить изменения' : 'Добавить анализ'}
                  </button>
                  <button
                    onClick={resetForm}
                    className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
                  >
                    Отмена
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            {fields.map((field) => {
              const fieldData = getFieldData(field.id);
              if (fieldData.length === 0) return null;

              return (
                <div key={field.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
                    <h4 className="text-gray-900">{field.name}</h4>
                    <p className="text-gray-600">Площадь: {field.area} га</p>
                  </div>

                  {fieldData.map((data) => (
                    <div key={data.id} className="p-6 border-b border-gray-100 last:border-b-0">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <p className="text-gray-600">Дата анализа: {new Date(data.date).toLocaleDateString('ru-RU')}</p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleEdit(data)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(data.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
                        <div className={`bg-${getNutrientLevel(data.nitrogen, 'nitrogen').color}-50 rounded-lg p-3`}>
                          <p className="text-gray-700 mb-1">Азот (N)</p>
                          <p className="text-gray-900">{data.nitrogen} мг/кг</p>
                          <p className={`text-${getNutrientLevel(data.nitrogen, 'nitrogen').color}-700 mt-1`}>
                            {getNutrientLevel(data.nitrogen, 'nitrogen').level}
                          </p>
                        </div>

                        <div className={`bg-${getNutrientLevel(data.phosphorus, 'phosphorus').color}-50 rounded-lg p-3`}>
                          <p className="text-gray-700 mb-1">Фосфор (P)</p>
                          <p className="text-gray-900">{data.phosphorus} мг/кг</p>
                          <p className={`text-${getNutrientLevel(data.phosphorus, 'phosphorus').color}-700 mt-1`}>
                            {getNutrientLevel(data.phosphorus, 'phosphorus').level}
                          </p>
                        </div>

                        <div className={`bg-${getNutrientLevel(data.potassium, 'potassium').color}-50 rounded-lg p-3`}>
                          <p className="text-gray-700 mb-1">Калий (K)</p>
                          <p className="text-gray-900">{data.potassium} мг/кг</p>
                          <p className={`text-${getNutrientLevel(data.potassium, 'potassium').color}-700 mt-1`}>
                            {getNutrientLevel(data.potassium, 'potassium').level}
                          </p>
                        </div>

                        <div className={`bg-${getPhLevel(data.pH).color}-50 rounded-lg p-3`}>
                          <p className="text-gray-700 mb-1">pH</p>
                          <p className="text-gray-900">{data.pH}</p>
                          <p className={`text-${getPhLevel(data.pH).color}-700 mt-1`}>
                            {getPhLevel(data.pH).level}
                          </p>
                        </div>

                        <div className="bg-green-50 rounded-lg p-3">
                          <p className="text-gray-700 mb-1">Органика</p>
                          <p className="text-gray-900">{data.organicMatter || 0}%</p>
                          <p className="text-green-700 mt-1">
                            {data.organicMatter < 2 ? 'Низкое' : data.organicMatter > 4 ? 'Высокое' : 'Среднее'}
                          </p>
                        </div>
                      </div>

                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h5 className="text-blue-900 mb-2">Рекомендации по удобрениям:</h5>
                        <ul className="space-y-1">
                          {getRecommendations(data).map((rec, idx) => (
                            <li key={idx} className="text-blue-800">
                              {rec}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {data.notes && (
                        <div className="mt-4 bg-gray-50 rounded-lg p-3">
                          <p className="text-gray-700">Примечания: {data.notes}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              );
            })}

            {soilData.length === 0 && (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <p className="text-gray-600">Анализы почвы пока не добавлены</p>
                <p className="text-gray-500 mt-2">Нажмите "Добавить анализ" для внесения данных</p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
