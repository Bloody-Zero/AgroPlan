import { useState, useEffect } from 'react';
import { Plus, Trash2, AlertCircle } from 'lucide-react';
import type { Field } from './MapFieldManager';

export interface CropRecord {
  id: string;
  fieldId: string;
  year: number;
  cropType: string;
}

const CROP_TYPES = [
  'Пшеница озимая',
  'Пшеница яровая',
  'Ячмень',
  'Овес',
  'Рожь',
  'Кукуруза',
  'Горох',
  'Соя',
  'Подсолнечник',
  'Рапс',
  'Сахарная свекла',
  'Картофель',
  'Лен',
  'Гречиха',
  'Многолетние травы',
  'Однолетние травы',
];

export function CropHistoryJournal() {
  const [fields, setFields] = useState<Field[]>([]);
  const [records, setRecords] = useState<CropRecord[]>([]);
  const [selectedField, setSelectedField] = useState('');
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedCrop, setSelectedCrop] = useState('');

  useEffect(() => {
    const savedFields = localStorage.getItem('fields');
    if (savedFields) {
      setFields(JSON.parse(savedFields));
    }

    const savedRecords = localStorage.getItem('cropRecords');
    if (savedRecords) {
      setRecords(JSON.parse(savedRecords));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('cropRecords', JSON.stringify(records));
  }, [records]);

  const addRecord = () => {
    if (!selectedField || !selectedCrop) return;

    // Проверка на дубликат
    const exists = records.find(
      (r) => r.fieldId === selectedField && r.year === selectedYear
    );
    if (exists) {
      alert('Запись для этого поля и года уже существует');
      return;
    }

    const newRecord: CropRecord = {
      id: Date.now().toString(),
      fieldId: selectedField,
      year: selectedYear,
      cropType: selectedCrop,
    };

    setRecords([...records, newRecord]);
    setSelectedCrop('');
  };

  const deleteRecord = (id: string) => {
    if (confirm('Удалить запись?')) {
      setRecords(records.filter((r) => r.id !== id));
    }
  };

  const getFieldName = (fieldId: string) => {
    return fields.find((f) => f.id === fieldId)?.name || 'Неизвестное поле';
  };

  const groupedRecords = fields.map((field) => {
    const fieldRecords = records
      .filter((r) => r.fieldId === field.id)
      .sort((a, b) => b.year - a.year);
    return { field, records: fieldRecords };
  });

  const years = Array.from({ length: 10 }, (_, i) => new Date().getFullYear() - i);

  return (
    <div className="space-y-6">
      {fields.length === 0 ? (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
          <div>
            <h3 className="text-yellow-900 mb-1">Нет добавленных полей</h3>
            <p className="text-yellow-700">
              Перейдите на вкладку "Учет полей" и добавьте поля на карте, прежде чем вести историю культур.
            </p>
          </div>
        </div>
      ) : (
        <>
          <div className="bg-green-50 border border-green-200 rounded-lg p-6">
            <h3 className="text-green-900 mb-4">Добавить запись в журнал</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-gray-700 mb-2">Поле</label>
                <select
                  value={selectedField}
                  onChange={(e) => setSelectedField(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                >
                  <option value="">Выберите поле</option>
                  {fields.map((field) => (
                    <option key={field.id} value={field.id}>
                      {field.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Год</label>
                <select
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(Number(e.target.value))}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                >
                  {years.map((year) => (
                    <option key={year} value={year}>
                      {year}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Культура</label>
                <select
                  value={selectedCrop}
                  onChange={(e) => setSelectedCrop(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                >
                  <option value="">Выберите культуру</option>
                  {CROP_TYPES.map((crop) => (
                    <option key={crop} value={crop}>
                      {crop}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-end">
                <button
                  onClick={addRecord}
                  disabled={!selectedField || !selectedCrop}
                  className="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Добавить
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-gray-900">История по полям</h3>
            {groupedRecords.map(({ field, records: fieldRecords }) => (
              <div key={field.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
                  <h4 className="text-gray-900">{field.name}</h4>
                  <p className="text-gray-600">Площадь: {field.area} га</p>
                </div>
                {fieldRecords.length === 0 ? (
                  <div className="px-4 py-8 text-center text-gray-500">
                    История посевов пока не добавлена
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                          <th className="px-4 py-3 text-left text-gray-700">Год</th>
                          <th className="px-4 py-3 text-left text-gray-700">Культура</th>
                          <th className="px-4 py-3 text-right text-gray-700">Действия</th>
                        </tr>
                      </thead>
                      <tbody>
                        {fieldRecords.map((record) => (
                          <tr key={record.id} className="border-b border-gray-100 hover:bg-gray-50">
                            <td className="px-4 py-3 text-gray-900">{record.year}</td>
                            <td className="px-4 py-3 text-gray-900">{record.cropType}</td>
                            <td className="px-4 py-3 text-right">
                              <button
                                onClick={() => deleteRecord(record.id)}
                                className="p-2 text-red-600 hover:bg-red-50 rounded"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
