import { useState, useEffect } from 'react';
import { FileDown, FileSpreadsheet, FileText, CheckCircle, Printer } from 'lucide-react';
import type { Field } from './MapFieldManager';
import type { CropRecord } from './CropHistoryJournal';

interface SoilData {
  id: string;
  fieldId: string;
  date: string;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  pH: number;
  organicMatter: number;
  notes: string;
}

export function ExportReports() {
  const [fields, setFields] = useState<Field[]>([]);
  const [cropRecords, setCropRecords] = useState<CropRecord[]>([]);
  const [soilData, setSoilData] = useState<SoilData[]>([]);
  const [exportType, setExportType] = useState<'all' | 'fields' | 'crops' | 'soil'>('all');
  const [selectedField, setSelectedField] = useState<string>('');
  const [exporting, setExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  useEffect(() => {
    const savedFields = localStorage.getItem('fields');
    if (savedFields) setFields(JSON.parse(savedFields));

    const savedRecords = localStorage.getItem('cropRecords');
    if (savedRecords) setCropRecords(JSON.parse(savedRecords));

    const savedSoilData = localStorage.getItem('soilData');
    if (savedSoilData) setSoilData(JSON.parse(savedSoilData));
  }, []);

  const getFieldName = (fieldId: string) => {
    return fields.find((f) => f.id === fieldId)?.name || 'Неизвестное поле';
  };

  const exportToHTML = () => {
    setExporting(true);
    try {
      let html = `
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>АгроПлан - Отчет</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
    h1 { color: #15803d; text-align: center; }
    h2 { color: #166534; border-bottom: 2px solid #15803d; padding-bottom: 5px; margin-top: 30px; }
    h3 { color: #166534; }
    .field { margin-bottom: 20px; padding: 15px; background: #f0fdf4; border-left: 4px solid #15803d; }
    .info { margin: 5px 0; }
    table { width: 100%; border-collapse: collapse; margin: 15px 0; }
    th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }
    th { background-color: #15803d; color: white; }
    .date { color: #666; font-size: 0.9em; }
    @media print {
      body { margin: 20px; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <h1>АгроПлан - Отчет</h1>
  <p class="date" style="text-align: center;">Дата создания: ${new Date().toLocaleDateString('ru-RU')}</p>
  <button class="no-print" onclick="window.print()" style="padding: 10px 20px; background: #15803d; color: white; border: none; border-radius: 5px; cursor: pointer; margin-bottom: 20px;">Печать / Сохранить как PDF</button>
`;

      // Поля
      if (exportType === 'all' || exportType === 'fields') {
        html += '<h2>ПОЛЯ</h2>';
        const fieldsToExport = selectedField ? fields.filter(f => f.id === selectedField) : fields;
        
        fieldsToExport.forEach((field) => {
          html += `
            <div class="field">
              <h3>${field.name}</h3>
              <p class="info">Площадь: ${field.area} га</p>
              <p class="info">Количество точек границы: ${field.coordinates.length}</p>
            </div>
          `;
        });
      }

      // История культур
      if (exportType === 'all' || exportType === 'crops') {
        html += '<h2>ИСТОРИЯ КУЛЬТУР</h2>';
        const recordsToExport = selectedField 
          ? cropRecords.filter(r => r.fieldId === selectedField)
          : cropRecords;

        const groupedByField: Record<string, CropRecord[]> = {};
        recordsToExport.forEach(record => {
          if (!groupedByField[record.fieldId]) {
            groupedByField[record.fieldId] = [];
          }
          groupedByField[record.fieldId].push(record);
        });

        Object.entries(groupedByField).forEach(([fieldId, records]) => {
          html += `<h3>${getFieldName(fieldId)}</h3>`;
          html += '<table><thead><tr><th>Год</th><th>Культура</th></tr></thead><tbody>';
          records
            .sort((a, b) => b.year - a.year)
            .forEach(record => {
              html += `<tr><td>${record.year}</td><td>${record.cropType}</td></tr>`;
            });
          html += '</tbody></table>';
        });
      }

      // Анализ почвы
      if (exportType === 'all' || exportType === 'soil') {
        html += '<h2>АНАЛИЗ ПОЧВЫ (NPK)</h2>';
        const soilToExport = selectedField 
          ? soilData.filter(s => s.fieldId === selectedField)
          : soilData;

        const groupedByField: Record<string, SoilData[]> = {};
        soilToExport.forEach(data => {
          if (!groupedByField[data.fieldId]) {
            groupedByField[data.fieldId] = [];
          }
          groupedByField[data.fieldId].push(data);
        });

        Object.entries(groupedByField).forEach(([fieldId, dataArray]) => {
          html += `<h3>${getFieldName(fieldId)}</h3>`;
          html += '<table><thead><tr><th>Дата</th><th>N (мг/кг)</th><th>P (мг/кг)</th><th>K (мг/кг)</th><th>pH</th><th>Органика %</th></tr></thead><tbody>';
          dataArray
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .forEach(data => {
              html += `<tr>
                <td>${new Date(data.date).toLocaleDateString('ru-RU')}</td>
                <td>${data.nitrogen}</td>
                <td>${data.phosphorus}</td>
                <td>${data.potassium}</td>
                <td>${data.pH}</td>
                <td>${data.organicMatter}</td>
              </tr>`;
              if (data.notes) {
                html += `<tr><td colspan="6"><em>Примечания: ${data.notes}</em></td></tr>`;
              }
            });
          html += '</tbody></table>';
        });
      }

      html += '</body></html>';

      // Создаем новое окно с отчетом
      const newWindow = window.open('', '_blank');
      if (newWindow) {
        newWindow.document.write(html);
        newWindow.document.close();
      }
      
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (error) {
      console.error('Error exporting HTML:', error);
      alert('Ошибка при экспорте отчета');
    } finally {
      setExporting(false);
    }
  };

  const exportToCSV = () => {
    setExporting(true);
    try {
      let csv = '';

      // Поля
      if (exportType === 'all' || exportType === 'fields') {
        csv += 'ПОЛЯ\n';
        csv += 'Название,Площадь (га),Количество точек,Центр X,Центр Y\n';
        const fieldsToExport = selectedField ? fields.filter(f => f.id === selectedField) : fields;
        
        fieldsToExport.forEach((field) => {
          csv += `"${field.name}",${field.area},${field.coordinates.length},${field.center[0].toFixed(2)},${field.center[1].toFixed(2)}\n`;
        });
        csv += '\n';
      }

      // История культур
      if (exportType === 'all' || exportType === 'crops') {
        csv += 'ИСТОРИЯ КУЛЬТУР\n';
        csv += 'Поле,Год,Культура\n';
        const recordsToExport = selectedField 
          ? cropRecords.filter(r => r.fieldId === selectedField)
          : cropRecords;

        recordsToExport
          .sort((a, b) => b.year - a.year)
          .forEach(record => {
            csv += `"${getFieldName(record.fieldId)}",${record.year},"${record.cropType}"\n`;
          });
        csv += '\n';
      }

      // Анализ почвы
      if (exportType === 'all' || exportType === 'soil') {
        csv += 'АНАЛИЗ ПОЧВЫ\n';
        csv += 'Поле,Дата,Азот (N) мг/кг,Фосфор (P) мг/кг,Калий (K) мг/кг,pH,Органика %,Примечания\n';
        const soilToExport = selectedField 
          ? soilData.filter(s => s.fieldId === selectedField)
          : soilData;

        soilToExport
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
          .forEach(data => {
            csv += `"${getFieldName(data.fieldId)}",${new Date(data.date).toLocaleDateString('ru-RU')},${data.nitrogen},${data.phosphorus},${data.potassium},${data.pH},${data.organicMatter},"${data.notes}"\n`;
          });
      }

      // Создание и скачивание файла
      const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `АгроПлан_Данные_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (error) {
      console.error('Error exporting CSV:', error);
      alert('Ошибка при экспорте CSV');
    } finally {
      setExporting(false);
    }
  };

  const exportToJSON = () => {
    setExporting(true);
    try {
      const data: any = {};

      if (exportType === 'all' || exportType === 'fields') {
        data.fields = selectedField ? fields.filter(f => f.id === selectedField) : fields;
      }

      if (exportType === 'all' || exportType === 'crops') {
        data.cropRecords = selectedField 
          ? cropRecords.filter(r => r.fieldId === selectedField)
          : cropRecords;
      }

      if (exportType === 'all' || exportType === 'soil') {
        data.soilData = selectedField 
          ? soilData.filter(s => s.fieldId === selectedField)
          : soilData;
      }

      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `АгроПлан_Данные_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (error) {
      console.error('Error exporting JSON:', error);
      alert('Ошибка при экспорте JSON');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-6">
        <h3 className="text-indigo-900 mb-4">Экспорт отчётов и данных</h3>
        <p className="text-indigo-700 mb-4">
          Экспортируйте данные в различных форматах для дальнейшего анализа, архивирования или передачи.
        </p>

        <div className="space-y-4">
          <div>
            <label className="block text-gray-700 mb-2">Что экспортировать</label>
            <select
              value={exportType}
              onChange={(e) => setExportType(e.target.value as any)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
            >
              <option value="all">Все данные</option>
              <option value="fields">Только поля</option>
              <option value="crops">Только история культур</option>
              <option value="soil">Только анализ почвы</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-700 mb-2">Фильтр по полю (опционально)</label>
            <select
              value={selectedField}
              onChange={(e) => setSelectedField(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
            >
              <option value="">Все поля</option>
              {fields.map((field) => (
                <option key={field.id} value={field.id}>
                  {field.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {exportSuccess && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <p className="text-green-700">Файл успешно экспортирован!</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={exportToHTML}
          disabled={exporting || fields.length === 0}
          className="bg-white border-2 border-red-300 rounded-lg p-6 hover:bg-red-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <div className="flex items-center justify-center mb-3">
            <Printer className="w-12 h-12 text-red-600" />
          </div>
          <h4 className="text-gray-900 mb-2">Печать / PDF</h4>
          <p className="text-gray-600">
            Откройте отчёт для печати или сохранения в PDF через браузер
          </p>
          {exporting && (
            <div className="mt-3">
              <div className="inline-block animate-spin rounded-full h-6 w-6 border-2 border-red-600 border-t-transparent"></div>
            </div>
          )}
        </button>

        <button
          onClick={exportToCSV}
          disabled={exporting || fields.length === 0}
          className="bg-white border-2 border-green-300 rounded-lg p-6 hover:bg-green-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <div className="flex items-center justify-center mb-3">
            <FileSpreadsheet className="w-12 h-12 text-green-600" />
          </div>
          <h4 className="text-gray-900 mb-2">Экспорт в CSV</h4>
          <p className="text-gray-600">
            Экспортируйте данные в формате CSV для работы в Excel и других таблицах
          </p>
          {exporting && (
            <div className="mt-3">
              <div className="inline-block animate-spin rounded-full h-6 w-6 border-2 border-green-600 border-t-transparent"></div>
            </div>
          )}
        </button>

        <button
          onClick={exportToJSON}
          disabled={exporting || fields.length === 0}
          className="bg-white border-2 border-blue-300 rounded-lg p-6 hover:bg-blue-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <div className="flex items-center justify-center mb-3">
            <FileDown className="w-12 h-12 text-blue-600" />
          </div>
          <h4 className="text-gray-900 mb-2">Экспорт в JSON</h4>
          <p className="text-gray-600">
            Сохраните структурированные данные для резервного копирования или импорта
          </p>
          {exporting && (
            <div className="mt-3">
              <div className="inline-block animate-spin rounded-full h-6 w-6 border-2 border-blue-600 border-t-transparent"></div>
            </div>
          )}
        </button>
      </div>

      <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
        <h4 className="text-gray-900 mb-3">Информация о данных</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg p-4 border border-gray-200">
            <p className="text-gray-600 mb-1">Полей</p>
            <p className="text-gray-900">{fields.length}</p>
          </div>
          <div className="bg-white rounded-lg p-4 border border-gray-200">
            <p className="text-gray-600 mb-1">Записей истории</p>
            <p className="text-gray-900">{cropRecords.length}</p>
          </div>
          <div className="bg-white rounded-lg p-4 border border-gray-200">
            <p className="text-gray-600 mb-1">Анализов почвы</p>
            <p className="text-gray-900">{soilData.length}</p>
          </div>
          <div className="bg-white rounded-lg p-4 border border-gray-200">
            <p className="text-gray-600 mb-1">Общая площадь</p>
            <p className="text-gray-900">
              {fields.reduce((sum, f) => sum + f.area, 0).toFixed(2)} га
            </p>
          </div>
        </div>
      </div>

      {fields.length === 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
          <p className="text-yellow-800">
            Нет данных для экспорта. Добавьте поля и другие данные для начала работы.
          </p>
        </div>
      )}
    </div>
  );
}
