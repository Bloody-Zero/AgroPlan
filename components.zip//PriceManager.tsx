import { useState, useEffect } from 'react';
import { RefreshCw, TrendingUp, TrendingDown, DollarSign, AlertCircle, Edit2, Save, X } from 'lucide-react';

interface CurrencyRate {
  usd: number;
  eur: number;
  date: string;
}

interface PriceCoefficients {
  basePrices: Record<string, number>;
  lastUpdated: string;
  inflationRate: number;
  seasonalCoefficients: Record<string, number>;
}

export function PriceManager() {
  const [currencyRates, setCurrencyRates] = useState<CurrencyRate | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [priceCoefficients, setPriceCoefficients] = useState<PriceCoefficients>(() => {
    const saved = localStorage.getItem('priceCoefficients');
    if (saved) {
      return JSON.parse(saved);
    }
    return {
      basePrices: {
        'Пшеница озимая': 14000,
        'Пшеница яровая': 13000,
        'Ячмень': 11000,
        'Овес': 9000,
        'Рожь': 10000,
        'Кукуруза': 12000,
        'Горох': 18000,
        'Соя': 25000,
        'Подсолнечник': 30000,
        'Рапс': 28000,
        'Сахарная свекла': 3500,
        'Картофель': 8000,
        'Лен': 35000,
        'Гречиха': 22000,
      },
      lastUpdated: new Date().toISOString(),
      inflationRate: 7.5,
      seasonalCoefficients: {
        'Январь': 1.1,
        'Февраль': 1.12,
        'Март': 1.15,
        'Апрель': 1.1,
        'Май': 1.05,
        'Июнь': 1.0,
        'Июль': 0.95,
        'Август': 0.9,
        'Сентябрь': 0.92,
        'Октябрь': 0.95,
        'Ноябрь': 1.0,
        'Декабрь': 1.05,
      },
    };
  });

  const [editingCrop, setEditingCrop] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState('');
  const [customInflation, setCustomInflation] = useState(priceCoefficients.inflationRate.toString());

  useEffect(() => {
    localStorage.setItem('priceCoefficients', JSON.stringify(priceCoefficients));
  }, [priceCoefficients]);

  useEffect(() => {
    fetchCurrencyRates();
  }, []);

  const fetchCurrencyRates = async () => {
    setLoading(true);
    setError(null);
    try {
      // Используем API ЦБ РФ для получения курсов валют
      const response = await fetch('https://www.cbr-xml-daily.ru/daily_json.js');
      if (!response.ok) throw new Error('Ошибка загрузки данных');
      
      const data = await response.json();
      setCurrencyRates({
        usd: data.Valute.USD.Value,
        eur: data.Valute.EUR.Value,
        date: data.Date,
      });
    } catch (err) {
      setError('Не удалось загрузить курсы валют');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getCurrentSeasonalCoefficient = () => {
    const months = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 
                    'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
    const currentMonth = months[new Date().getMonth()];
    return priceCoefficients.seasonalCoefficients[currentMonth] || 1.0;
  };

  const getAdjustedPrice = (basePrice: number) => {
    const seasonalCoeff = getCurrentSeasonalCoefficient();
    const inflationCoeff = 1 + (priceCoefficients.inflationRate / 100);
    
    // Учитываем время с последнего обновления
    const monthsSinceUpdate = Math.floor(
      (new Date().getTime() - new Date(priceCoefficients.lastUpdated).getTime()) / (1000 * 60 * 60 * 24 * 30)
    );
    const timeCoeff = Math.pow(inflationCoeff, monthsSinceUpdate / 12);
    
    return Math.round(basePrice * seasonalCoeff * timeCoeff);
  };

  const handleEditPrice = (crop: string) => {
    setEditingCrop(crop);
    setEditPrice(priceCoefficients.basePrices[crop].toString());
  };

  const handleSavePrice = () => {
    if (!editingCrop) return;
    const newPrice = parseFloat(editPrice);
    if (isNaN(newPrice) || newPrice <= 0) {
      alert('Введите корректную цену');
      return;
    }

    setPriceCoefficients({
      ...priceCoefficients,
      basePrices: {
        ...priceCoefficients.basePrices,
        [editingCrop]: newPrice,
      },
      lastUpdated: new Date().toISOString(),
    });
    setEditingCrop(null);
  };

  const handleUpdateInflation = () => {
    const newRate = parseFloat(customInflation);
    if (isNaN(newRate) || newRate < 0 || newRate > 100) {
      alert('Введите корректную ставку инфляции (0-100%)');
      return;
    }

    setPriceCoefficients({
      ...priceCoefficients,
      inflationRate: newRate,
      lastUpdated: new Date().toISOString(),
    });
  };

  const getEconomicIndicators = () => {
    if (!currencyRates) return null;

    // Базовые курсы для сравнения (примерно на начало 2024)
    const baseUSD = 90;
    const baseEUR = 100;

    const usdChange = ((currencyRates.usd - baseUSD) / baseUSD) * 100;
    const eurChange = ((currencyRates.eur - baseEUR) / baseEUR) * 100;

    return {
      usdChange,
      eurChange,
      averageChange: (usdChange + eurChange) / 2,
    };
  };

  const indicators = getEconomicIndicators();

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-blue-900 mb-1">Управление ценами</h3>
            <p className="text-blue-700">
              Актуализируйте цены с учётом текущей экономической ситуации в России
            </p>
          </div>
          <button
            onClick={fetchCurrencyRates}
            disabled={loading}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Обновить курсы
          </button>
        </div>

        {currencyRates && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4 border border-blue-200">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-5 h-5 text-green-600" />
                <span className="text-gray-700">USD/RUB</span>
              </div>
              <p className="text-gray-900">{currencyRates.usd.toFixed(2)} ₽</p>
              {indicators && (
                <p className={`mt-1 flex items-center gap-1 ${indicators.usdChange > 0 ? 'text-red-600' : 'text-green-600'}`}>
                  {indicators.usdChange > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  {Math.abs(indicators.usdChange).toFixed(1)}% к базе
                </p>
              )}
            </div>

            <div className="bg-white rounded-lg p-4 border border-blue-200">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-5 h-5 text-blue-600" />
                <span className="text-gray-700">EUR/RUB</span>
              </div>
              <p className="text-gray-900">{currencyRates.eur.toFixed(2)} ₽</p>
              {indicators && (
                <p className={`mt-1 flex items-center gap-1 ${indicators.eurChange > 0 ? 'text-red-600' : 'text-green-600'}`}>
                  {indicators.eurChange > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  {Math.abs(indicators.eurChange).toFixed(1)}% к базе
                </p>
              )}
            </div>

            <div className="bg-white rounded-lg p-4 border border-blue-200">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-orange-600" />
                <span className="text-gray-700">Инфляция</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={customInflation}
                  onChange={(e) => setCustomInflation(e.target.value)}
                  className="w-20 px-2 py-1 border border-gray-300 rounded"
                  step="0.1"
                />
                <span className="text-gray-900">%</span>
                <button
                  onClick={handleUpdateInflation}
                  className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                  title="Обновить"
                >
                  <Save className="w-4 h-4" />
                </button>
              </div>
              <p className="text-gray-600 mt-1">Годовая ставка</p>
            </div>
          </div>
        )}

        {error && (
          <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600" />
            <p className="text-red-700">{error}</p>
          </div>
        )}
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-gray-900 mb-4">Базовые цены реализации (руб/тонна)</h3>
        <p className="text-gray-600 mb-4">
          Последнее обновление: {new Date(priceCoefficients.lastUpdated).toLocaleDateString('ru-RU')}
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {Object.entries(priceCoefficients.basePrices).map(([crop, basePrice]) => {
            const adjustedPrice = getAdjustedPrice(basePrice);
            const difference = adjustedPrice - basePrice;
            const percentChange = (difference / basePrice) * 100;

            return (
              <div key={crop} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <div className="flex justify-between items-start mb-2">
                  <p className="text-gray-900">{crop}</p>
                  {editingCrop !== crop ? (
                    <button
                      onClick={() => handleEditPrice(crop)}
                      className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                      title="Редактировать базовую цену"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                  ) : null}
                </div>

                {editingCrop === crop ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        value={editPrice}
                        onChange={(e) => setEditPrice(e.target.value)}
                        className="flex-1 px-3 py-1 border border-gray-300 rounded"
                        autoFocus
                      />
                      <span>₽</span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={handleSavePrice}
                        className="flex-1 px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 flex items-center justify-center gap-1"
                      >
                        <Save className="w-3 h-3" />
                        Сохранить
                      </button>
                      <button
                        onClick={() => setEditingCrop(null)}
                        className="px-3 py-1 bg-gray-500 text-white rounded hover:bg-gray-600"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Базовая:</span>
                        <span className="text-gray-900">{basePrice.toLocaleString()} ₽</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Текущая:</span>
                        <span className="text-green-700">{adjustedPrice.toLocaleString()} ₽</span>
                      </div>
                    </div>
                    {difference !== 0 && (
                      <div className={`mt-2 flex items-center gap-1 ${difference > 0 ? 'text-orange-600' : 'text-green-600'}`}>
                        {difference > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                        <span>{percentChange > 0 ? '+' : ''}{percentChange.toFixed(1)}%</span>
                      </div>
                    )}
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-green-50 border border-green-200 rounded-lg p-6">
        <h3 className="text-green-900 mb-3">Сезонные коэффициенты</h3>
        <p className="text-green-700 mb-4">
          Текущий месяц: {new Date().toLocaleDateString('ru-RU', { month: 'long' })} 
          (коэффициент: {getCurrentSeasonalCoefficient().toFixed(2)})
        </p>
        <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
          {Object.entries(priceCoefficients.seasonalCoefficients).map(([month, coeff]) => {
            const currentMonth = new Date().toLocaleDateString('ru-RU', { month: 'long' });
            const isCurrent = month.toLowerCase() === currentMonth.toLowerCase();
            
            return (
              <div
                key={month}
                className={`text-center p-3 rounded-lg ${
                  isCurrent ? 'bg-green-200 border-2 border-green-600' : 'bg-white border border-green-200'
                }`}
              >
                <p className="text-gray-700">{month.slice(0, 3)}</p>
                <p className={`${isCurrent ? 'text-green-900' : 'text-gray-900'}`}>
                  {coeff.toFixed(2)}x
                </p>
              </div>
            );
          })}
        </div>
        <p className="text-gray-600 mt-4">
          💡 Сезонные коэффициенты учитывают изменение цен в течение года из-за сезона сбора урожая
        </p>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
          <div>
            <p className="text-yellow-900">Важная информация</p>
            <p className="text-yellow-700 mt-1">
              Цены являются ориентировочными и рассчитаны на основе средних рыночных данных. 
              Фактические цены могут отличаться в зависимости от региона, качества продукции и условий поставки. 
              Рекомендуется уточнять актуальные цены у местных закупщиков и на товарных биржах.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
